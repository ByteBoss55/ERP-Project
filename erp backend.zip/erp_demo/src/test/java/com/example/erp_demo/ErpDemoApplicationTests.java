package com.example.erp_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
