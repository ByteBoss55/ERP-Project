package com.example.erp_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.CrossOrigin;
 
@CrossOrigin(origins = "http://localhost:3000")
@SpringBootApplication
@ComponentScan(basePackages = "com.example.erp_demo")
public class ErpDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpDemoApplication.class, args);
	}
}
