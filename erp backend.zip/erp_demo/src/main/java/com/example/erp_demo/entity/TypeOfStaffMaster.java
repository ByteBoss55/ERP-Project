package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "type_of_staff_master")
public class TypeOfStaffMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer staff_id;

    @Column(name = "type_of_staff", length = 100)
    private String typeOfStaff;

    public Integer getStaffId() {
        return staff_id;
    }

    public void setStaffId(Integer staffId) {
        this.staff_id = staffId;
    }

    public String getTypeOfStaff() {
        return typeOfStaff;
    }

    public void setTypeOfStaff(String typeOfStaff) {
        this.typeOfStaff = typeOfStaff;
    }
}
