package com.example.erp_demo.repository;

import com.example.erp_demo.entity.ColourMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ColourRepository extends JpaRepository<ColourMaster, Integer> {
}
