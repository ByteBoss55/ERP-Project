package com.example.erp_demo.entity;

 

import jakarta.persistence.*;

@Entity
@Table(name = "department_master")
public class DepartmentMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "did")
    private Integer did;

    @Column(name = "d_name", length = 100)
    private String dName;

    public Integer getDid() {
        return did;
    }

    public void setDid(Integer did) {
        this.did = did;
    }

    public String getDName() {
        return dName;
    }

    public void setDName(String dName) {
        this.dName = dName;
    }
}

