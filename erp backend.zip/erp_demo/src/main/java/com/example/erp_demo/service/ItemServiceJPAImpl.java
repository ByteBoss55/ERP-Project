package com.example.erp_demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Item;
import com.example.erp_demo.projection.ItemMasterProjection;
import com.example.erp_demo.repository.ItemRepoJPA;

@Service
public class ItemServiceJPAImpl implements ItemServiceJPA {

    @Autowired
    private ItemRepoJPA itemRepo;

    @Override
    public List<ItemMasterProjection> getAllItems() {
        return itemRepo.getAllItems(); // SP call
    }

    @Override
    public Optional<Item> getItemById(Integer id) {
        return itemRepo.findById(id);
    }

    @Override
    public Item createItem(Item item) {
    	System.out.println("Branch ID = " + item.getBranchId());
        return itemRepo.save(item);
    }

    @Override
    public Item updateItem(Integer id, Item updatedItem) {
        return itemRepo.findById(id)
                .map(existing -> {

                    existing.setItemCode(updatedItem.getItemCode());
                    existing.setItemName(updatedItem.getItemName());
                    existing.setMaterial(updatedItem.getMaterial());
                    existing.setItemType(updatedItem.getItemType());
                    existing.setItemSubType(updatedItem.getItemSubType());
                    existing.setHsn_code(updatedItem.getHsn_code());
                    existing.setGstRate(updatedItem.getGstRate());
                    existing.setPurchaseCost(updatedItem.getPurchaseCost());
                    existing.setSellingPrice(updatedItem.getSellingPrice());
                    existing.setUsername(updatedItem.getUsername());
                    existing.setLoginBranch(updatedItem.getLoginBranch());
                    existing.setSystemEntryDate(updatedItem.getSystemEntryDate());
                    existing.setRawMaterial(updatedItem.getRawMaterial());
                    existing.setSubCategoryId(updatedItem.getSubCategoryId());
                    existing.setManufacturerId(updatedItem.getManufacturerId());
                    existing.setColourId(updatedItem.getColourId());
                    existing.setUnitId(updatedItem.getUnitId());
                    existing.setBranchId(updatedItem.getBranchId());
                    existing.setCategoryId(updatedItem.getCategoryId());
                    existing.setDrawingNo(updatedItem.getDrawingNo());
                    existing.setSpecification(updatedItem.getSpecification());

                    return itemRepo.save(existing);
                })
                .orElseThrow(() -> new RuntimeException("Item not found with ID: " + id));
    }

    @Override
    public void deleteItem(Integer id) {
        if (!itemRepo.existsById(id)) {
            throw new RuntimeException("Item not found with ID: " + id);
        }
        itemRepo.deleteById(id);
    }

    // Save with auto-generated item code
    @Override
    public Item saveItem(Item item) {
        String nextItemCode = itemRepo.generateNextItemCode();
        item.setItemCode(nextItemCode);
        item.setId(null);
        return itemRepo.save(item);
    }

    @Override
    public Item updateItemWithCode(int id, Item item) {
        Item existing = itemRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found with ID: " + id));

        item.setItemCode(existing.getItemCode());
        item.setId(id);

        return itemRepo.save(item);
    }
}
