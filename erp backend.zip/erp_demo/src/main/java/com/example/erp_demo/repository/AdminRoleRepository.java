package com.example.erp_demo.repository;

import com.example.erp_demo.entity.AdminRoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRoleRepository extends JpaRepository<AdminRoleMaster, Integer> {
}
