package com.example.erp_demo.repository;

import com.example.erp_demo.entity.AttendanceMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttendanceRepository extends JpaRepository<AttendanceMaster, Integer> {
}
