package com.example.erp_demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.erp_demo.entity.Employee;
import com.example.erp_demo.entity.Item;
import com.example.erp_demo.service.EmployeeService;
import com.example.erp_demo.service.EmployeeServiceJPA;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@GetMapping("nextEmpcode")
	 public ResponseEntity<String> getNextEmployeeCode() {
	        String nextCode = service.generateNextEmpCode();
	        return ResponseEntity.ok(nextCode);
	    }
	    
	@PostMapping("/saveemployee")
	public ResponseEntity<Employee> create(@RequestBody Employee employee) {
		return ResponseEntity.ok(service.create(employee));
	}

 
	@GetMapping("/getAllEmployees")
	public List<Employee> getAllEmployees() {
		return service.getAllEmployees();
	}

 
	@GetMapping("/getEmployeeById/{e_sr_no}")
	public ResponseEntity<?> getEmployeeById(@PathVariable Integer id) {
		Employee employee = service.getEmployeeById(id);
		if (employee == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee with ID " + id + " not found.");
		} else {
			return ResponseEntity.ok(employee);
		}
	}

 
	@PutMapping("/updateemployee/{e_sr_no}")
	 public ResponseEntity<?> updateItem(@PathVariable Integer id, @RequestBody Employee employee) {

    	employee.setESrNo(id);
        boolean updated = service.updateEmployee(id, employee);

        if (updated) {
            return ResponseEntity.ok("Employee updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to update employee.");
        }
    }

	@DeleteMapping("/deleteemployee/{e_sr_no}")
	public ResponseEntity<String> deleteEmployee(@PathVariable Integer id) {
		boolean deleted = service.deleteEmployee(id);
		return deleted ? ResponseEntity.ok("Employee deleted successfully.")
				: ResponseEntity.status(500).body("Failed to delete employee.");
	}
//----------------------------------------------------------------------------------------------------------------------------------------------
    
    // ✅ Endpoint to save employee (auto-generates empCode using stored procedure)

   @Autowired
    private EmployeeServiceJPA employeeService;
 
    @PostMapping("/savegenerateNextEmployeeCode")
    public Employee saveEmployee(@RequestBody Employee employee) {
        return employeeService.saveEmployee(employee);
    }
    
//    @PutMapping("/updategenerateNextEmployeeCode/{id}")
//    public ResponseEntity<?> updateEmployee(
//            @PathVariable Integer id,
//            @RequestBody Employee employee) {
//
//        Employee updated = employeeService.updateEmployeeWithCode(id, employee);
//        if (updated == null) {
//            return ResponseEntity.badRequest().body("Employee not found");
//        }
//        return ResponseEntity.ok(updated);
//    }
}