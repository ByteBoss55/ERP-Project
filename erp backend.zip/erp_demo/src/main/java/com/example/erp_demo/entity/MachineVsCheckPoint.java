package com.example.erp_demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "machine_vs_check_point")
public class MachineVsCheckPoint {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer cid;
	
	@Column(name = "machine_id")
	private Integer machineId;
	
	@Column(name = "location", length = 255)
	private String location;
	
	@Column(name = "parameter", length = 255)
	private String parameter;
	
	@Column(name = "plan_type_id")
	private Integer planTypeId;
	
	public MachineVsCheckPoint() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return cid;
	}

	public void setId(Integer id) {
		this.cid = id;
	}

	public Integer getMachineId() {
		return machineId;
	}

	public void setMachineId(Integer machineId) {
		this.machineId = machineId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public Integer getPlanTypeId() {
		return planTypeId;
	}

	public void setPlanTypeId(Integer planTypeId) {
		this.planTypeId = planTypeId;
	}

	public Integer getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(Integer scheduleId) {
		this.scheduleId = scheduleId;
	}

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getCmpName() {
		return cmpName;
	}

	public void setCmpName(String cmpName) {
		this.cmpName = cmpName;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getFinancialYear() {
		return financialYear;
	}

	public void setFinancialYear(String financialYear) {
		this.financialYear = financialYear;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getCheckPointId() {
		return checkPointId;
	}

	public void setCheckPointId(Integer checkPointId) {
		this.checkPointId = checkPointId;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	@Column(name = "schedule_id")
	private Integer scheduleId;
	
	@Column(name = "entry_date", length = 255)
	private String entryDate;
	
	@Column(name = "cmp_name", length = 50)
	private String cmpName;
	
	@Column(name = "ip_address", length = 50)
	private String ipAddress;
	
	@Column(name = "financial_year", length = 255)
	private String financialYear;
	
	@Column(name = "user_name", length = 255)
	private String userName;
	
	@Column(name = "password", length = 255)
	private String password;
	
	@Column(name = "check_point_id")
	private Integer checkPointId;
	
	@Column(name = "serial_number")
	private String serialNumber;
}
