package com.example.erp_demo.service;

import java.util.List;
import java.util.Optional;
 
import com.example.erp_demo.entity.Employee;

public interface EmployeeServiceJPA {
  
	List<Employee> getAllEmployees();

    Optional<Employee> getEmployeeById(Long eSrNo);

    Optional<Employee> getEmployeeByCode(String employeeCode);

    Employee updateEmployee(Long eSrNo, Employee updatedEmployee);

    void deleteEmployee(Long eSrNo);
    
    Employee saveEmployee(Employee employee);

	 
}
