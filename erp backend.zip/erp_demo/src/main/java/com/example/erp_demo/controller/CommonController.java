package com.example.erp_demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.entity.City;
import com.example.erp_demo.entity.Country;
import com.example.erp_demo.entity.State;
import com.example.erp_demo.service.CascadingService;


	@RestController
	@RequestMapping("/api/cascade")
	@CrossOrigin(origins = "http://localhost:3000")
	public class CommonController {

	    @Autowired
	    private CascadingService cascadingService;

	    // --------------------- COUNTRY LIST ---------------------
	    @GetMapping("/getallcountries")
	    public List<Country> getAllCountries() {
	        return cascadingService.getAllCountries();
	    }

	    // --------------------- STATE LIST BY COUNTRY ---------------------
	    @GetMapping("getStatesByCountry/{countryId}")
	    public List<State> getStatesByCountry(@PathVariable Integer countryId) {
	        return cascadingService.getStatesByCountry(countryId);
	    }

	    // --------------------- CITY LIST BY STATE ---------------------
	    @GetMapping("/getCitiesByState/{stateId}")
	    public List<City> getCitiesByState(@PathVariable Integer stateId) {
	        return cascadingService.getCitiesByState(stateId);
	    }
	}

