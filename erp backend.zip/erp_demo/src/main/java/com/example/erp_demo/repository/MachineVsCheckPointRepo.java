package com.example.erp_demo.repository;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.erp_demo.entity.MachineVsCheckPoint;

@Repository
public class MachineVsCheckPointRepo {

	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	public Long create(MachineVsCheckPoint machine) {
	    return jdbcTemplate.execute(
	        (CallableStatementCreator) connection -> {
	            CallableStatement cs = connection.prepareCall(
	                "{CALL insert_machine_vs_check_point(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}"
	            );

	            // Use setObject() for nullable Integer columns
	            cs.setObject(1, machine.getMachineId(), Types.INTEGER);
	            cs.setString(2, machine.getLocation());
	            cs.setString(3, machine.getParameter());
	            cs.setObject(4, machine.getPlanTypeId(), Types.INTEGER);
	            cs.setObject(5, machine.getScheduleId(), Types.INTEGER);
	            cs.setString(6, machine.getEntryDate());
	            cs.setString(7, machine.getCmpName());
	            cs.setString(8, machine.getIpAddress());
	            cs.setString(9, machine.getFinancialYear());
	            cs.setString(10, machine.getUserName());
	            cs.setString(11, machine.getPassword());
	            cs.setObject(12, machine.getCheckPointId(), Types.INTEGER); // changed to setObject for null safety
	            cs.setString(13, machine.getSerialNumber());

	            cs.registerOutParameter(14, Types.BIGINT); // OUT param for inserted ID
	            return cs;
	        },
	        (CallableStatementCallback<Long>) cs -> {
	            cs.execute();
	            return cs.getLong(14);
	        }
	    );
	}
	
	public List<MachineVsCheckPoint> getAllMachineVsCheckPoint() {
        return jdbcTemplate.execute((ConnectionCallback<List<MachineVsCheckPoint>>) con -> {
            try (var cs = con.prepareCall("{CALL get_all_machine_vs_check_points()}")) {
                List<MachineVsCheckPoint> list = new ArrayList<>();
                try (ResultSet rs = cs.executeQuery()) {
                    while (rs.next()) {
                        MachineVsCheckPoint machine = new MachineVsCheckPoint();
                        machine.setId(rs.getInt("id"));
                        machine.setMachineId(rs.getInt("machine_id"));
                        machine.setLocation(rs.getString("location"));
                        machine.setParameter(rs.getString("parameter"));
                        machine.setPlanTypeId(rs.getInt("plan_type_id"));
                        machine.setScheduleId(rs.getInt("schedule_id"));
                        machine.setEntryDate(rs.getString("entry_date"));
                        machine.setCmpName(rs.getString("cmp_name"));
                        machine.setIpAddress(rs.getString("ip_address"));
                        machine.setFinancialYear(rs.getString("financial_year"));
                        machine.setUserName(rs.getString("user_name"));
                        machine.setPassword(rs.getString("password"));
                        machine.setCheckPointId(rs.getInt("check_point_id"));
                        machine.setSerialNumber(rs.getString("serial_number"));
                        list.add(machine);
                    }
                }
                return list;
            }
        });
    }

	public MachineVsCheckPoint getByIdMachineVsCheckPoint(Integer id) {
        return jdbcTemplate.execute((ConnectionCallback<MachineVsCheckPoint>) con -> {
            try (var cs = con.prepareCall("{CALL get_machine_vs_check_point_by_id(?)}")) {
                cs.setInt(1, id);
                try (ResultSet rs = cs.executeQuery()) {
                    if (rs.next()) {
                        MachineVsCheckPoint machine = new MachineVsCheckPoint();
                        machine.setId(rs.getInt("id"));
                        machine.setMachineId(rs.getInt("machine_id"));
                        machine.setLocation(rs.getString("location"));
                        machine.setParameter(rs.getString("parameter"));
                        machine.setPlanTypeId(rs.getInt("plan_type_id"));
                        machine.setScheduleId(rs.getInt("schedule_id"));
                        machine.setEntryDate(rs.getString("entry_date"));
                        machine.setCmpName(rs.getString("cmp_name"));
                        machine.setIpAddress(rs.getString("ip_address"));
                        machine.setFinancialYear(rs.getString("financial_year"));
                        machine.setUserName(rs.getString("user_name"));
                        machine.setPassword(rs.getString("password"));
                        machine.setCheckPointId(rs.getInt("check_point_id"));
                        machine.setSerialNumber(rs.getString("serial_number"));
                        return machine;
                    }
                }
            }
            return null;
        });
    }

	public boolean update(MachineVsCheckPoint machine) {
        String sql = "{CALL update_machine_vs_check_point(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        int rows = jdbcTemplate.update(connection -> {
            var cs = connection.prepareCall(sql);
            cs.setInt(1, machine.getId());
            cs.setInt(2, machine.getMachineId());
            cs.setString(3, machine.getLocation());
            cs.setString(4, machine.getParameter());
            cs.setInt(5, machine.getPlanTypeId());
            cs.setInt(6, machine.getScheduleId());
            cs.setString(7, machine.getEntryDate());
            cs.setString(8, machine.getCmpName());
            cs.setString(9, machine.getIpAddress());
            cs.setString(10, machine.getFinancialYear());
            cs.setString(11, machine.getUserName());
            cs.setString(12, machine.getPassword());
            cs.setInt(13, machine.getCheckPointId());
            cs.setString(14, machine.getSerialNumber());
            return cs;
        });

        return rows > 0;
    }
	
	 public boolean delete(Integer id) {
	        String sql = "{CALL delete_machine_vs_check_point(?)}";

	        int rows = jdbcTemplate.update(connection -> {
	            var cs = connection.prepareCall(sql);
	            cs.setInt(1, id);
	            return cs;
	        });

	        return rows > 0;
	    }
}
