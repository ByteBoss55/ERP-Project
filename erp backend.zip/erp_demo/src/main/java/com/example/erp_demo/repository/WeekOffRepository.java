package com.example.erp_demo.repository;

import com.example.erp_demo.entity.WeekOffMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WeekOffRepository extends JpaRepository<WeekOffMaster, Integer> {
}

