package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "check_point_master")
public class CheckPointMaster {

    @Id
    @Column(name = "check_point_id", length = 255)
    private Integer checkPointId;

    @Column(name = "checkpoint_name", length = 50)
    private String checkpointName;

    public Integer getCheckPointId() {
        return checkPointId;
    }

    public void setCheckPointId(Integer checkPointId) {
        this.checkPointId = checkPointId;
    }

    public String getCheckpointName() {
        return checkpointName;
    }

    public void setCheckpointName(String checkpointName) {
        this.checkpointName = checkpointName;
    }
}

