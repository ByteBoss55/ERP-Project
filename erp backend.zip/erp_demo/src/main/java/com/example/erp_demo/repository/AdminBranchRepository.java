package com.example.erp_demo.repository;

import com.example.erp_demo.entity.AdminBranchMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminBranchRepository extends JpaRepository<AdminBranchMaster, Integer> {
}

