package com.example.erp_demo.service;

import java.util.List;
import java.util.Optional;

import com.example.erp_demo.entity.Customer;
import com.example.erp_demo.entity.Item;
import com.example.erp_demo.projection.CustomerMasterProjection;

public interface CustomerServiceJPA {

	List<CustomerMasterProjection> getAllCustomers();

    Optional<Customer> getCustomerById(Long id);

    Optional<Customer> getCustomerByCode(String customerCode);

    Customer updateCustomer(Long id, Customer updatedCustomer);

    void deleteCustomer(Long id);
    
    Customer saveCustomer(Customer customer);          
    
}
