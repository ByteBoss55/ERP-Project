package com.example.erp_demo.repository;

import com.example.erp_demo.entity.CustomerTypeMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerTypeRepository extends JpaRepository<CustomerTypeMaster, Integer> {
}
