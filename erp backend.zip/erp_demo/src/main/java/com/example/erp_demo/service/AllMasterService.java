package com.example.erp_demo.service;

import com.example.erp_demo.entity.*;
import com.example.erp_demo.repository.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AllMasterService {

	private final GenderRepository genderRepo;
    private final DesignationRepository designationRepo;
    private final DepartmentRepository departmentRepo;
    private final CustomerTypeRepository customerTypeRepo;
    private final ContractorRepository contractorRepo;
    private final ColourRepository colourRepo;
    private final CheckPointRepository checkpointRepo;
    private final CategoryRepository categoryRepo;
    private final BloodGroupRepository bloodRepo;
    private final AttendanceRepository attendanceRepo;
    private final AdminRoleRepository adminRoleRepo;
    private final AdminLoginUserRepository loginUserRepo;
    private final AdminLoginRollRepository loginRollRepo;
    private final AdminBranchRepository branchRepo;
    private final MaritalStatusRepository maritalRepo;
    private final MachineTypeRepository machineTypeRepo;
    private final ManufacturerRepository manufacturerRepo;
    private final MachineSchedulerRepository schedulerRepo;
    private final LeaveRepository leaveRepo;
    private final WeekOffRepository weekOffRepo;
    private final UnitRepository unitRepo;
    private final TypeOfStaffRepository staffTypeRepo;
    private final SupplierTypeRepository supplierTypeRepo;
    private final SubCategoryRepository subCategoryRepo;
    private final PayTypeRepository payTypeRepo;
    private final QualificationRepository qualificationRepo;

    public AllMasterService(
            GenderRepository genderRepo,
            DesignationRepository designationRepo,
            DepartmentRepository departmentRepo,
            CustomerTypeRepository customerTypeRepo,
            ContractorRepository contractorRepo,
            ColourRepository colourRepo,
            CheckPointRepository checkpointRepo,
            CategoryRepository categoryRepo,
            BloodGroupRepository bloodRepo,
            AttendanceRepository attendanceRepo,
            AdminRoleRepository adminRoleRepo,
            AdminLoginUserRepository loginUserRepo,
            AdminLoginRollRepository loginRollRepo,
            AdminBranchRepository branchRepo,
            MaritalStatusRepository maritalRepo,
            MachineTypeRepository machineTypeRepo,
            ManufacturerRepository manufacturerRepo,
            MachineSchedulerRepository schedulerRepo,
            LeaveRepository leaveRepo,
            WeekOffRepository weekOffRepo,
            UnitRepository unitRepo,
            TypeOfStaffRepository staffTypeRepo,
            SupplierTypeRepository supplierTypeRepo,
            SubCategoryRepository subCategoryRepo,
            PayTypeRepository payTypeRepo,
            QualificationRepository qualificationRepo){
        this.genderRepo = genderRepo;
        this.designationRepo = designationRepo;
        this.departmentRepo = departmentRepo;
        this.customerTypeRepo = customerTypeRepo;
        this.contractorRepo = contractorRepo;
        this.colourRepo = colourRepo;
        this.checkpointRepo = checkpointRepo;
        this.categoryRepo = categoryRepo;
        this.bloodRepo = bloodRepo;
        this.attendanceRepo = attendanceRepo;
        this.adminRoleRepo = adminRoleRepo;
        this.loginUserRepo = loginUserRepo;
        this.loginRollRepo = loginRollRepo;
        this.branchRepo = branchRepo;
        this.maritalRepo = maritalRepo;
        this.machineTypeRepo = machineTypeRepo;
        this.manufacturerRepo = manufacturerRepo;
        this.schedulerRepo = schedulerRepo;
        this.leaveRepo = leaveRepo;
        this.weekOffRepo = weekOffRepo;
        this.unitRepo = unitRepo;
        this.staffTypeRepo = staffTypeRepo;
        this.supplierTypeRepo = supplierTypeRepo;
        this.subCategoryRepo = subCategoryRepo;
        this.payTypeRepo = payTypeRepo;
        this.qualificationRepo = qualificationRepo;
         
    }


    public List<GenderMaster> getAllGender() { return genderRepo.findAll(); }
    public List<DesignationMaster> getAllDesignation() { return designationRepo.findAll(); }
    public List<DepartmentMaster> getAllDepartment() { return departmentRepo.findAll(); }
    public List<CustomerTypeMaster> getAllCustomerType() { return customerTypeRepo.findAll(); }
    public List<ContractorMaster> getAllContractor() { return contractorRepo.findAll(); }
    public List<ColourMaster> getAllColour() { return colourRepo.findAll(); }
    public List<CheckPointMaster> getAllCheckPoint() { return checkpointRepo.findAll(); }
    public List<CategoryMaster> getAllCategory() { return categoryRepo.findAll(); }
    public List<BloodGroupMaster> getAllBloodGroup() { return bloodRepo.findAll(); }
    public List<AttendanceMaster> getAllAttendance() { return attendanceRepo.findAll(); }
    public List<AdminRoleMaster> getAllAdminRole() { return adminRoleRepo.findAll(); }
    public List<AdminLoginUserMaster> getAllLoginUser() { return loginUserRepo.findAll(); }
    public List<AdminLoginRollMaster> getAllLoginRoll() { return loginRollRepo.findAll(); }
    public List<AdminBranchMaster> getAllBranch() { return branchRepo.findAll(); }
    public List<MaritalStatusMaster> getAllMaritalStatus() { return maritalRepo.findAll(); }
    public List<MachineTypeMaster> getAllMachineType() { return machineTypeRepo.findAll(); }
    public List<ManufacturerMaster> getAllManufacturer() { return manufacturerRepo.findAll(); }
    public List<MachineScheduler> getAllScheduler() { return schedulerRepo.findAll(); }
    public List<LeaveMaster> getAllLeave() { return leaveRepo.findAll(); }
    public List<WeekOffMaster> getAllWeekOff() { return weekOffRepo.findAll(); }
    public List<UnitMaster> getAllUnits() { return unitRepo.findAll(); }
    public List<TypeOfStaffMaster> getAllStaffTypes() { return staffTypeRepo.findAll(); }
    public List<SupplierTypeMaster> getAllSupplierTypes() { return supplierTypeRepo.findAll(); }
    public List<SubCategoryMaster> getAllSubCategories() { return subCategoryRepo.findAll(); }
    public List<PayType> getAllPayTypes() { return payTypeRepo.findAll(); }
    public List<QualificationMaster> getAllQualifications() { return qualificationRepo.findAll(); }

}
