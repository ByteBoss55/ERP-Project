package com.example.erp_demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.City; 
import com.example.erp_demo.entity.Country;
import com.example.erp_demo.entity.State;
import com.example.erp_demo.repository.CityRepo;
import com.example.erp_demo.repository.CountryRepo;
import com.example.erp_demo.repository.StateRepo;

@Service
public class CascadingService {

	@Autowired
    private CountryService countryService;

    @Autowired
    private StateService stateService;

    @Autowired
    private CityService cityService;


    // ------------------- COUNTRY METHODS -------------------
    public List<Country> getAllCountries() {
        return countryService.getAllCountries();
    }

    // ------------------- STATE METHODS -------------------
    public List<State> getStatesByCountry(Integer countryId) {
        return stateService.getStatesByCountry(countryId);
    }

    
    public List<City> getCitiesByState(Integer stateId) {
        return cityService.getCitiesByState(stateId);
    }
}


 
@Service
class CountryService {

    @Autowired
    private CountryRepo countryRepository;

    public List<Country> getAllCountries() {
        return countryRepository.findAll();
    }
}


 
@Service
class StateService {

    @Autowired
    private StateRepo stateRepository;

    public List<State> getStatesByCountry(Integer countryId) {
        return stateRepository.findByCountry_CountryId(countryId);
    }
}


// -------------------------------------------------------------
// CITY SERVICE (non-public)
// -------------------------------------------------------------
@Service
class CityService {

    @Autowired
    private CityRepo cityRepository;

    public List<City> getCitiesByState(Integer stateId) {
        return cityRepository.findByState_StateId(stateId);
    }
}

