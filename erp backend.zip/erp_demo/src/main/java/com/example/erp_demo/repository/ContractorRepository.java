package com.example.erp_demo.repository;

import com.example.erp_demo.entity.ContractorMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContractorRepository extends JpaRepository<ContractorMaster, Integer> {
}
