package com.example.erp_demo.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

@Entity
@Table(name = "item_master")
public class Item {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private Integer id;

	// ---------------- MAIN FIELDS ---------------- //

	@Column(name = "item_code")
	private String itemCode;

	@Column(name = "item_name")
	private String itemName;

	private String material;

	@Column(name = "item_type")
	private String itemType;

	@Column(name = "item_sub_type")
	private String itemSubType;

	@JsonProperty("hsn_code")
	private String hsn_code;

	@JsonProperty("gst_rate")
	private Double gst_rate;

	@JsonProperty("purchase_cost")
	private Double purchase_cost;

	@JsonProperty("selling_price")
	private Double selling_price;

	private String username;

	@JsonProperty("login_branch")
	private String login_branch;

	@Column(name = "system_entry_date")
	@JsonProperty("system_entry_date")
	private String system_entry_date;

	@JsonProperty("raw_material")
	private String raw_material;

	@JsonProperty("sub_category_id")
	private Integer sub_category_id;

	@JsonProperty("manufacturer_id")
	private Integer manufacturer_id;

	@JsonProperty("colour_id")
	private Integer colour_id;

	@JsonProperty("unit_id")
	private Integer unit_id;

 
 
	
    @Column(name = "branch_id")
	@JsonProperty("branch_id")
	private Integer branch_id;

	@JsonProperty("category_id")
	private Integer category_id;

	@JsonProperty("drawing_no")
	private String drawing_no;

	private String specification;

	// ---------------- TRANSIENT (JOINED TABLE) FIELDS ---------------- //

	@Transient
	private String colour_name;

	@Transient
	private String unit_name;

	@Transient
	private String manufacturer_name;

	@Transient
	private String category_name;

	@Transient
	private String sub_category_name;

	@Transient
	private String branch_name;
	 
 

	// ---------------- GETTERS & SETTERS ---------------- //

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String item_code) {
		this.itemCode = item_code;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String item_type) {
		this.itemType = item_type;
	}

	public String getItemSubType() {
		return itemSubType;
	}

	public void setItemSubType(String item_sub_type) {
		this.itemSubType = item_sub_type;
	}

	public String getHsn_code() {
		return hsn_code;
	}

	public void setHsn_code(String hsn_code) {
		this.hsn_code = hsn_code;
	}

	public Double getGstRate() {
		return gst_rate;
	}

	public void setGstRate(Double gst_rate) {
		this.gst_rate = gst_rate;
	}

	public Double getPurchaseCost() {
		return purchase_cost;
	}

	public void setPurchaseCost(Double purchase_cost) {
		this.purchase_cost = purchase_cost;
	}

	public Double getSellingPrice() {
		return selling_price;
	}

	public void setSellingPrice(Double selling_price) {
		this.selling_price = selling_price;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLoginBranch() {
		return login_branch;
	}

	public void setLoginBranch(String login_branch) {
		this.login_branch = login_branch;
	}

	public String getSystemEntryDate() {
		return system_entry_date;
	}

	public void setSystemEntryDate(String system_entry_date) {
		this.system_entry_date = system_entry_date;
	}

	public String getRawMaterial() {
		return raw_material;
	}

	public void setRawMaterial(String raw_material) {
		this.raw_material = raw_material;
	}

	public Integer getSubCategoryId() {
		return sub_category_id;
	}

	public void setSubCategoryId(Integer sub_category_id) {
		this.sub_category_id = sub_category_id;
	}

	public Integer getManufacturerId() {
		return manufacturer_id;
	}

	public void setManufacturerId(Integer manufacturer_id) {
		this.manufacturer_id = manufacturer_id;
	}

	public Integer getColourId() {
		return colour_id;
	}

	public void setColourId(Integer colour_id) {
		this.colour_id = colour_id;
	}

	public Integer getUnitId() {
		return unit_id;
	}

	public void setUnitId(Integer unit_id) {
		this.unit_id = unit_id;
	}

	public Integer getBranchId() {
		return branch_id;
	}

	public void setBranchId(Integer branch_id) {
		this.branch_id = branch_id;
	}

	public Integer getCategoryId() {
		return category_id;
	}

	public void setCategoryId(Integer category_id) {
		this.category_id = category_id;
	}

	public String getDrawingNo() {
		return drawing_no;
	}

	public void setDrawingNo(String drawing_no) {
		this.drawing_no = drawing_no;
	}

	public String getSpecification() {
		return specification;
	}

	public void setSpecification(String specification) {
		this.specification = specification;
	}

	// ----------- NEW FIELDS GETTERS/SETTERS ------------ //

	public String getColourName() {
		return colour_name;
	}

	public void setColourName(String colour_name) {
		this.colour_name = colour_name;
	}

	public String getUnitName() {
		return unit_name;
	}

	public void setUnitName(String unit_name) {
		this.unit_name = unit_name;
	}

	public String getManufacturerName() {
		return manufacturer_name;
	}

	public void setManufacturerName(String manufacturer_name) {
		this.manufacturer_name = manufacturer_name;
	}

	public String getCategoryName() {
		return category_name;
	}

	public void setCategoryName(String category_name) {
		this.category_name = category_name;
	}

	public String getSubCategoryName() {
		return sub_category_name;
	}

	public void setSubCategoryName(String sub_category_name) {
		this.sub_category_name = sub_category_name;
	}

	public String getBranchName() {
		return branch_name;
	}

	public void setBranchName(String branch_name) {
		this.branch_name = branch_name;
	}
}
