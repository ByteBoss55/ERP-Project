package com.example.erp_demo.repository;

import com.example.erp_demo.entity.ManufacturerMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerRepository extends JpaRepository<ManufacturerMaster, Integer> {
}

