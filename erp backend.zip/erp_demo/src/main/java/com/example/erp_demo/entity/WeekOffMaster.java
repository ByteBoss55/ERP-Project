package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "week_off_master")
public class WeekOffMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer wid;

    @Column(name = "week_off", length = 50)
    private String weekOff;

    public Integer getWid() {
        return wid;
    }

    public void setWid(Integer wid) {
        this.wid = wid;
    }

    public String getWeekOff() {
        return weekOff;
    }

    public void setWeekOff(String weekOff) {
        this.weekOff = weekOff;
    }
}
