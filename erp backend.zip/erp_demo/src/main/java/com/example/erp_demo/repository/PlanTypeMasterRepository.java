package com.example.erp_demo.repository;

 

import com.example.erp_demo.entity.PlanTypeMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PlanTypeMasterRepository extends JpaRepository<PlanTypeMaster, Integer> {

}

