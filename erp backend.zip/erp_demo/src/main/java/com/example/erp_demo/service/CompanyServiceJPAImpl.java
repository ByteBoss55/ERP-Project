package com.example.erp_demo.service;

import java.util.List;
 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Company;
import com.example.erp_demo.repository.CompanyRepoJPA;

@Service
public class CompanyServiceJPAImpl implements CompanyServiceJPA {
	
	@Autowired
    private CompanyRepoJPA companyRepoJPA;

    @Override
    public List<Company> getAllCompanies() {
        return companyRepoJPA.findAll();
    }

    @Override
    public Company create(Company company) {
        return companyRepoJPA.save(company);
    }

	@Override
	public boolean updateCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCompany(Integer id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Company getCompanyById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

    

}
