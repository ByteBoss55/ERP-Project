package com.example.erp_demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Customer;
import com.example.erp_demo.projection.CustomerMasterProjection;
import com.example.erp_demo.repository.CustomerRepoJPA;

@Service
public class CustomerServiceJPAImpl implements CustomerServiceJPA {

	@Autowired
	private CustomerRepoJPA customerRepo;

	@Override
	public List<CustomerMasterProjection> getAllCustomers() {
		return customerRepo.getAllCustomers();
	}

	@Override
	public Optional<Customer> getCustomerById(Long id) {
		return customerRepo.findById(id);
	}

	@Override
	public Optional<Customer> getCustomerByCode(String customerCode) {
		return customerRepo.findByCustCode(customerCode);
	}

	@Override
	public Customer updateCustomer(Long id, Customer updatedCustomer) {
		return customerRepo.findById(id).map(existing -> {
			existing.setCustCode(updatedCustomer.getCustCode());
			existing.setCustName(updatedCustomer.getCustName());
			existing.setContactPerson(updatedCustomer.getContactPerson());
			existing.setBranch(updatedCustomer.getBranch());
			existing.setAddress1(updatedCustomer.getAddress1());
			existing.setAddress2(updatedCustomer.getAddress2());
			existing.setPinCode(updatedCustomer.getPinCode());
			existing.setEmailId(updatedCustomer.getEmailId());
			existing.setTelephone(updatedCustomer.getTelephone());
			existing.setMobile(updatedCustomer.getMobile());
			existing.setFax(updatedCustomer.getFax());
			existing.setWebsite(updatedCustomer.getWebsite());
			existing.setGstIn(updatedCustomer.getGstIn());
			existing.setRemarks(updatedCustomer.getRemarks());
			existing.setUsername(updatedCustomer.getUsername());
			existing.setLoginBranch(updatedCustomer.getLoginBranch());
			existing.setSystemEntryDate(updatedCustomer.getSystemEntryDate());
			existing.setCustomerTypeId(updatedCustomer.getCustomerTypeId());
			existing.setCityId(updatedCustomer.getCityId());
			existing.setStateId(updatedCustomer.getStateId());
			existing.setCountryId(updatedCustomer.getCountryId());
			existing.setBranchId(updatedCustomer.getBranchId());
			existing.setLoginUserId(updatedCustomer.getLoginUserId());
			return customerRepo.save(existing);
		}).orElseThrow(() -> new RuntimeException("Customer not found with ID: " + id));
	}

	 

	@Override
	public Customer saveCustomer(Customer customer) {

		String nextCustomerCode = customerRepo.generateNextCustomerCode();
		customer.setCustCode(nextCustomerCode);
		customer.setId(null);

		return customerRepo.save(customer);
	}

	@Override
	public void deleteCustomer(Long id) {
		// TODO Auto-generated method stub
		if (!customerRepo.existsById(id)) {
			throw new RuntimeException("Customer not found with ID: " + id);
		}
		customerRepo.deleteById(id);
	}
}	

