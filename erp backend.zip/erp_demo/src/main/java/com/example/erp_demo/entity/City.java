package com.example.erp_demo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "city_master")
public class City {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "city_id")
	@JsonProperty("id")
    private Integer cityId;

    @Column(name = "city_name", length = 250)
    @JsonProperty("name")
    private String cityName;

    @ManyToOne
    @JoinColumn(name = "state_id")
    @JsonProperty("state_id")
    private State state;

    // Getters & Setters
    public Integer getCityId() {
        return cityId;
    }
    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }
    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public State getState() {
        return state;
    }
    public void setState(State state) {
        this.state = state;
    }
}

