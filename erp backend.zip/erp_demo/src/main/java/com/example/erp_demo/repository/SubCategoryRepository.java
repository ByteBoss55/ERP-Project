package com.example.erp_demo.repository;

import com.example.erp_demo.entity.SubCategoryMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubCategoryRepository extends JpaRepository<SubCategoryMaster, Integer> {
}
