package com.example.erp_demo.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.repository.AdminLoginUserMasterDao;



@Service
public class AdminLoginUserMasterService {
	
	@Autowired
	 AdminLoginUserMasterDao adminloginusermasterdao;
	

	public Map<String, Object> authenticateAdminUser1(String username, String password) {
		return adminloginusermasterdao.authenticateAdminUser1(username, password);

	}
	
	public void logoutAdminUser(int loginUserId) {
		adminloginusermasterdao.logoutAdminUser(loginUserId);
		
	}
	
}
