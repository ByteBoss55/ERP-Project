package com.example.erp_demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.entity.MachineVsCheckPoint;
import com.example.erp_demo.service.MachineVsCheckPointService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class MachineVsCheckPointController {

    @Autowired
    private MachineVsCheckPointService service;

    
    @PostMapping("/savemachinevscheckpoint")
    public ResponseEntity<MachineVsCheckPoint> create(@RequestBody MachineVsCheckPoint machine) {
        return ResponseEntity.ok(service.create(machine));
    }
 
    @GetMapping("/getAllMachineVsCheckPoints")
    public List<MachineVsCheckPoint> getAllMachineVsCheckPoints() {
        return service.getAllMachineVsCheckPoints();
    }

    
    @GetMapping("/getMachineVsCheckPointById/{id}")
    public ResponseEntity<?> getMachineVsCheckPointById(@PathVariable Integer id) {
        MachineVsCheckPoint machine = service.getMachineVsCheckPointById(id);
        if (machine == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("MachineVsCheckPoint with ID " + id + " not found.");
        } else {
            return ResponseEntity.ok(machine);
        }
    }

    
    @PutMapping("/updatemachinevscheckpoint")
    public ResponseEntity<String> updateMachineVsCheckPoint(@RequestBody MachineVsCheckPoint machine) {
        boolean updated = service.updateMachineVsCheckPoint(machine);
        return updated
                ? ResponseEntity.ok("MachineVsCheckPoint updated successfully.")
                : ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Failed to update MachineVsCheckPoint.");
    }

     
    @DeleteMapping("/deletemachinevscheckpoint/{id}")
    public ResponseEntity<String> deleteMachineVsCheckPoint(@PathVariable Integer id) {
        boolean deleted = service.deleteMachineVsCheckPoint(id);
        return deleted
                ? ResponseEntity.ok("MachineVsCheckPoint deleted successfully.")
                : ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("Failed to delete MachineVsCheckPoint.");
    }
}
