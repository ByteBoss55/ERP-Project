package com.example.erp_demo.repository;

import com.example.erp_demo.entity.CategoryMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<CategoryMaster, Integer> {
}
