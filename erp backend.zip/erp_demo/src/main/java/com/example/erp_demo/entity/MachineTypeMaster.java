package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "machine_type_master")
public class MachineTypeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "machine_type_id")
    private Integer machineTypeId;

    @Column(name = "machine_type_name", length = 100)
    private String machineTypeName;

    @Column(name = "is_active")
    private Boolean isActive;

    public Integer getMachineTypeId() {
        return machineTypeId;
    }

    public void setMachineTypeId(Integer machineTypeId) {
        this.machineTypeId = machineTypeId;
    }

    public String getMachineTypeName() {
        return machineTypeName;
    }

    public void setMachineTypeName(String machineTypeName) {
        this.machineTypeName = machineTypeName;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
}
