package com.example.erp_demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "company_master")
public class Company {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer id;

	    @Column(name = "company_name", length = 255)
	    private String companyName;

	    @Column(name = "address1", length = 255)
	    private String address1;

	    @Column(name = "address2", length = 255)
	    private String address2;

	    @Column(name = "city_id")
	    private Integer cityId;

	    @Column(name = "state_id")
	    private Integer stateId;

	    @Column(name = "country_id")
	    private Integer countryId;

	    @Column(name = "pin_code", length = 255)
	    private String pinCode;

	    @Column(name = "email_id", length = 255)
	    private String emailId;

	    @Column(name = "telephone", length = 255)
	    private String telephone;

	    @Column(name = "mobile", length = 255)
	    private String mobile;

	    @Column(name = "contact_person", length = 50)
	    private String contactPerson;

	    @Column(name = "website", length = 50)
	    private String website;

	    @Column(name = "gst_in", length = 255)
	    private String gstIn;

	    @Column(name = "system_date", length = 255)
	    private String systemDate;

	    // ✅ Getters and Setters
	    public Integer getId() {
	        return id;
	    }

	    public void setId(Integer id) {
	        this.id = id;
	    }

	    public String getCompanyName() {
	        return companyName;
	    }

	    public void setCompanyName(String companyName) {
	        this.companyName = companyName;
	    }

	    public String getAddress1() {
	        return address1;
	    }

	    public void setAddress1(String address1) {
	        this.address1 = address1;
	    }

	    public String getAddress2() {
	        return address2;
	    }

	    public void setAddress2(String address2) {
	        this.address2 = address2;
	    }

	    public Integer getCityId() {
	        return cityId;
	    }

	    public void setCityId(Integer cityId) {
	        this.cityId = cityId;
	    }

	    public Integer getStateId() {
	        return stateId;
	    }

	    public void setStateId(Integer stateId) {
	        this.stateId = stateId;
	    }

	    public Integer getCountryId() {
	        return countryId;
	    }

	    public void setCountryId(Integer countryId) {
	        this.countryId = countryId;
	    }

	    public String getPinCode() {
	        return pinCode;
	    }

	    public void setPinCode(String pinCode) {
	        this.pinCode = pinCode;
	    }

	    public String getEmailId() {
	        return emailId;
	    }

	    public void setEmailId(String emailId) {
	        this.emailId = emailId;
	    }

	    public String getTelephone() {
	        return telephone;
	    }

	    public void setTelephone(String telephone) {
	        this.telephone = telephone;
	    }

	    public String getMobile() {
	        return mobile;
	    }

	    public void setMobile(String mobile) {
	        this.mobile = mobile;
	    }

	    public String getContactPerson() {
	        return contactPerson;
	    }

	    public void setContactPerson(String contactPerson) {
	        this.contactPerson = contactPerson;
	    }

	    public String getWebsite() {
	        return website;
	    }

	    public void setWebsite(String website) {
	        this.website = website;
	    }

	    public String getGstIn() {
	        return gstIn;
	    }

	    public void setGstIn(String gstIn) {
	        this.gstIn = gstIn;
	    }

	    public String getSystemDate() {
	        return systemDate;
	    }

	    public void setSystemDate(String systemDate) {
	        this.systemDate = systemDate;
	    }
	  }
	
