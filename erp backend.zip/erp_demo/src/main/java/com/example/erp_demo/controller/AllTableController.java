package com.example.erp_demo.controller;
 
import com.example.erp_demo.service.AllMasterService;
import com.example.erp_demo.entity.AdminBranchMaster;
import com.example.erp_demo.entity.AdminLoginRollMaster;
import com.example.erp_demo.entity.AdminLoginUserMaster;
import com.example.erp_demo.entity.AdminRoleMaster;
import com.example.erp_demo.entity.AttendanceMaster;
import com.example.erp_demo.entity.BloodGroupMaster;
import com.example.erp_demo.entity.CategoryMaster;
import com.example.erp_demo.entity.CheckPointMaster;
import com.example.erp_demo.entity.ColourMaster;
import com.example.erp_demo.entity.ContractorMaster;
import com.example.erp_demo.entity.CustomerTypeMaster;
import com.example.erp_demo.entity.DepartmentMaster;
import com.example.erp_demo.entity.DesignationMaster;
import com.example.erp_demo.entity.GenderMaster;
import com.example.erp_demo.entity.LeaveMaster;
import com.example.erp_demo.entity.MachineScheduler;
import com.example.erp_demo.entity.MachineTypeMaster;
import com.example.erp_demo.entity.ManufacturerMaster;
import com.example.erp_demo.entity.MaritalStatusMaster;
import com.example.erp_demo.entity.PayType;
import com.example.erp_demo.entity.QualificationMaster;
import com.example.erp_demo.entity.SubCategoryMaster;
import com.example.erp_demo.entity.SupplierTypeMaster;
import com.example.erp_demo.entity.TypeOfStaffMaster;
import com.example.erp_demo.entity.UnitMaster;
import com.example.erp_demo.entity.WeekOffMaster;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
 
@CrossOrigin(origins = "http://localhost:3000")
public class AllTableController {

    private final AllMasterService service;

    public AllTableController(AllMasterService service) {
        this.service = service;
    }

    @GetMapping("/marital-status")
    public List<MaritalStatusMaster> getMaritalStatus() { return service.getAllMaritalStatus(); }

    @GetMapping("/machine-type")
    public List<MachineTypeMaster> getMachineType() { return service.getAllMachineType(); }

    @GetMapping("/manufacturer")
    public List<ManufacturerMaster> getManufacturer() { return service.getAllManufacturer(); }

    @GetMapping("/machine-scheduler")
    public List<MachineScheduler> getScheduler() { return service.getAllScheduler(); }

    @GetMapping("/leave")
    public List<LeaveMaster> getLeave() { return service.getAllLeave(); }

    @GetMapping("/gender")
    public List<GenderMaster> getGender() { return service.getAllGender(); }

    @GetMapping("/designation")
    public List<DesignationMaster> getDesignation() { return service.getAllDesignation(); }

    @GetMapping("/department")
    public List<DepartmentMaster> getDepartment() { return service.getAllDepartment(); }

    @GetMapping("/customer-type")
    public List<CustomerTypeMaster> getCustomerType() { return service.getAllCustomerType(); }

    @GetMapping("/contractor")
    public List<ContractorMaster> getContractor() { return service.getAllContractor(); }

    @GetMapping("/colour")
    public List<ColourMaster> getColour() { return service.getAllColour(); }

    @GetMapping("/checkpoint")
    public List<CheckPointMaster> getCheckPoint() { return service.getAllCheckPoint(); }

    @GetMapping("/category")
    public List<CategoryMaster> getCategory() { return service.getAllCategory(); }

    @GetMapping("/blood-group")
    public List<BloodGroupMaster> getBloodGroup() { return service.getAllBloodGroup(); }

    @GetMapping("/attendance")
    public List<AttendanceMaster> getAttendance() { return service.getAllAttendance(); }

    @GetMapping("/admin-role")
    public List<AdminRoleMaster> getAdminRole() { return service.getAllAdminRole(); }

    @GetMapping("/login-user")
    public List<AdminLoginUserMaster> getLoginUser() { return service.getAllLoginUser(); }

    @GetMapping("/login-roll")
    public List<AdminLoginRollMaster> getLoginRoll() { return service.getAllLoginRoll(); }

    @GetMapping("/branch")
    public List<AdminBranchMaster> getBranch() { return service.getAllBranch(); }
    
    @GetMapping("/weekoff")
    public List<WeekOffMaster> getWeekOff() { return service.getAllWeekOff(); }

    @GetMapping("/units")
    public List<UnitMaster> getUnits() { return service.getAllUnits(); }

    @GetMapping("/staff-types")
    public List<TypeOfStaffMaster> getStaffTypes() { return service.getAllStaffTypes(); }

    @GetMapping("/supplier-types")
    public List<SupplierTypeMaster> getSupplierTypes() { return service.getAllSupplierTypes(); }

    @GetMapping("/sub-categories")
    public List<SubCategoryMaster> getSubCategories() { return service.getAllSubCategories(); }

    @GetMapping("/pay-types")
    public List<PayType> getPayTypes() { return service.getAllPayTypes(); }

    @GetMapping("/qualifications")
    public List<QualificationMaster> getQualifications() { return service.getAllQualifications(); }
}

