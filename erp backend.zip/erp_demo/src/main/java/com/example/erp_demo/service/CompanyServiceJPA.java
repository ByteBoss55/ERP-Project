package com.example.erp_demo.service;

import java.util.List;

import com.example.erp_demo.entity.Company;

public interface CompanyServiceJPA {

	List<Company> getAllCompanies();

	Company create(Company company);
	
	boolean updateCompany(Company company);

    boolean deleteCompany(Integer id);

    Company getCompanyById(Integer id);

}
