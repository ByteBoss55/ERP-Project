package com.example.erp_demo.repository;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

 
import com.example.erp_demo.entity.Customer;
 

@Repository
public class CustomerRepo {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Integer create(Customer cust) {

		// 1️⃣ Generate customer code here
		String nextCode = generateNextCustomerCode();
		cust.setCustCode(nextCode);

		return jdbcTemplate.execute((CallableStatementCreator) connection -> {
			CallableStatement cs = connection
					.prepareCall("{CALL master_customer_master_save(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			cs.setString(1, cust.getCustCode()); // <-- now always auto-generated
			cs.setString(2, cust.getCustName());
			cs.setString(3, cust.getContactPerson());
			cs.setString(4, cust.getBranch());
			cs.setString(5, cust.getAddress1());
			cs.setString(6, cust.getAddress2());
			cs.setObject(7, cust.getPinCode(), Types.INTEGER);
			cs.setString(8, cust.getEmailId());
			cs.setObject(9, cust.getTelephone(), Types.BIGINT);
			cs.setObject(10, cust.getMobile(), Types.BIGINT);
			cs.setString(11, cust.getFax());
			cs.setString(12, cust.getWebsite());
			cs.setString(13, cust.getGstIn());
			cs.setString(14, cust.getRemarks());
			cs.setString(15, cust.getUsername());
			cs.setString(16, cust.getLoginBranch());
			cs.setString(17, cust.getSystemEntryDate());
			cs.setObject(18, cust.getCustomerTypeId(), Types.INTEGER);
			cs.setObject(19, cust.getCityId(), Types.INTEGER);
			cs.setObject(20, cust.getStateId(), Types.INTEGER);
			cs.setObject(21, cust.getCountryId(), Types.INTEGER);
			cs.setObject(22, cust.getBranchId(), Types.INTEGER);
			cs.setObject(23, cust.getLoginUserId(), Types.INTEGER);

			return cs;

		}, (CallableStatementCallback<Integer>) cs -> {
			cs.execute();
			return 1;
		});
	}

	public String generateNextCustomerCode() {
		return jdbcTemplate.execute((CallableStatementCreator) connection -> {
			CallableStatement cs = connection.prepareCall("{CALL master_customer_master_generateNextCustCode(?)}");

			cs.registerOutParameter(1, Types.VARCHAR);
			return cs;

		}, (CallableStatementCallback<String>) cs -> {

			// Execute
			boolean hasResultSet = cs.execute();

			// 🔥 IMPORTANT — skip the SELECT result set from the stored procedure
			while (hasResultSet) {
				try (ResultSet rs = cs.getResultSet()) {
					// we do not need this SELECT output, so we ignore it
				}
				hasResultSet = cs.getMoreResults();
			}

			// Now OUT parameter is safe to read
			return cs.getString(1);
		});
	}

	public List<Customer> getAllCustomers() {
		return jdbcTemplate.execute((ConnectionCallback<List<Customer>>) con -> {
			try (var cs = con.prepareCall("{CALL master_customer_master_getAll()}")) {
				List<Customer> list = new ArrayList<>();
				try (ResultSet rs = cs.executeQuery()) {
					while (rs.next()) {
						Customer cust = new Customer();
						cust.setId(rs.getInt("id"));
						cust.setCustCode(rs.getString("cust_code"));
						cust.setCustName(rs.getString("cust_name"));
						cust.setContactPerson(rs.getString("contact_person"));
						cust.setBranch(rs.getString("branch"));
						cust.setAddress1(rs.getString("address1"));
						cust.setAddress2(rs.getString("address2"));
						cust.setPinCode(rs.getString("pin_code"));
						cust.setEmailId(rs.getString("email_id"));
						cust.setTelephone(rs.getLong("telephone" ));
						cust.setMobile(rs.getLong("mobile" ));
						cust.setFax(rs.getString("fax"));
						cust.setWebsite(rs.getString("website"));
						cust.setGstIn(rs.getString("gst_in"));
						cust.setRemarks(rs.getString("remarks"));
						cust.setUsername(rs.getString("username"));
						cust.setLoginBranch(rs.getString("login_branch"));
						cust.setSystemEntryDate(rs.getString("system_entry_date"));
						cust.setCustomerTypeId(rs.getObject("customer_type_id", Integer.class));
						cust.setCityId(rs.getObject("city_id", Integer.class));
						cust.setStateId(rs.getObject("state_id", Integer.class));
						cust.setCountryId(rs.getObject("country_id", Integer.class));
						cust.setBranchId(rs.getObject("branch_id", Integer.class));
						cust.setLoginUserId(rs.getObject("login_user_id", Integer.class));
						cust.setCountryName(rs.getString("country_name"));
						cust.setStateName(rs.getString("state_name"));
						cust.setCityName(rs.getString("city_name"));
						cust.setCustomer_type(rs.getString("customer_type"));
						cust.setBranchName(rs.getString("branch_name"));
						cust.setUserName(rs.getString("user_name")); 


						list.add(cust);
					}
				}
				return list;
			}
		});
	}

	public Customer getCustomerById(Long id) {
		return jdbcTemplate.execute((ConnectionCallback<Customer>) con -> {
			try (CallableStatement cs = con.prepareCall("{CALL master_customer_master_getById(?)}")) {
				cs.setLong(1, id);
				try (ResultSet rs = cs.executeQuery()) {
					if (rs.next()) {
						Customer cust = new Customer();
						cust.setId(rs.getInt("id"));
						cust.setCustCode(rs.getString("cust_code"));
						cust.setCustName(rs.getString("cust_name"));
						cust.setContactPerson(rs.getString("contact_person"));
						;
						cust.setBranch(rs.getString("branch"));
						cust.setAddress1(rs.getString("address1"));
						cust.setAddress2(rs.getString("address2"));
						cust.setPinCode(rs.getString("pin_code"));
						cust.setEmailId(rs.getString("email_id"));
						cust.setTelephone(rs.getLong("telephone"));
						cust.setMobile(rs.getLong("mobile"));
						cust.setFax(rs.getString("fax"));
						cust.setWebsite(rs.getString("website"));
						cust.setGstIn(rs.getString("gst_in"));
						cust.setRemarks(rs.getString("remarks"));
						cust.setUsername(rs.getString("username"));
						cust.setLoginBranch(rs.getString("login_branch"));
						cust.setSystemEntryDate(rs.getString("system_entry_date"));
						cust.setCustomerTypeId(rs.getObject("customer_type_id", Integer.class));
						cust.setCityId(rs.getObject("city_id", Integer.class));
						cust.setStateId(rs.getObject("state_id", Integer.class));
						cust.setCountryId(rs.getObject("country_id", Integer.class));
						cust.setBranchId(rs.getObject("branch_id", Integer.class));
						cust.setLoginUserId(rs.getObject("login_user_id", Integer.class));

						return cust;
					}
					return null;
				}
			}
		});
	}

	public boolean updateCustomer(Customer cust) {
		String sql = "{CALL master_customer_master_update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )}";

		int rowsAffected = jdbcTemplate.update(connection -> {
			var cs = connection.prepareCall(sql);
			cs.setLong(1, cust.getId());
			cs.setString(2, cust.getCustCode());
			cs.setString(3, cust.getCustName());
			cs.setString(4, cust.getContactPerson());
			cs.setString(5, cust.getBranch());
			cs.setString(6, cust.getAddress1());
			cs.setString(7, cust.getAddress2());
			cs.setObject(8, cust.getPinCode(), Types.INTEGER);
			cs.setString(9, cust.getEmailId());
			cs.setObject(10, cust.getTelephone(), Types.BIGINT);
			cs.setObject(11, cust.getMobile(), Types.BIGINT);
			cs.setString(12, cust.getFax());
			cs.setString(13, cust.getWebsite());
			cs.setString(14, cust.getGstIn());
			cs.setString(15, cust.getRemarks());
			cs.setString(16, cust.getUsername());
			cs.setString(17, cust.getLoginBranch());
			cs.setString(18, cust.getSystemEntryDate());
			cs.setObject(19, cust.getCustomerTypeId(), Types.INTEGER);
			cs.setObject(20, cust.getCityId(), Types.INTEGER);
			cs.setObject(21, cust.getStateId(), Types.INTEGER);
			cs.setObject(22, cust.getCountryId(), Types.INTEGER);
			cs.setObject(23, cust.getBranchId(), Types.INTEGER);
			cs.setObject(24, cust.getLoginUserId(), Types.INTEGER);
			return cs;
		});

		return rowsAffected > 0;
	}

	public boolean deleteCustomer(Long id) {
		String sql = "{CALL master_customer_master_deleteById(?)}";

		int rowsAffected = jdbcTemplate.update(connection -> {
			var cs = connection.prepareCall(sql);
			cs.setLong(1, id);
			return cs;
		});

		return rowsAffected > 0;
	}

	public List<Map<String, Object>> getAllCountries() {
		String sql = "CALL getAllCountryData()";
		return jdbcTemplate.queryForList(sql);
	}

	public List<Map<String, Object>> getAllStatesByCountryId(Integer countryId) {
		String sql = "CALL getAllStateDataByCountry(?)";
		return jdbcTemplate.queryForList(sql, countryId);
	}

	public List<Map<String, Object>> getAllCityByStateId(Integer stateId) {
		String sql = "CALL getAllCitiesDataByState(?)";
		return jdbcTemplate.queryForList(sql, stateId);
	}

	public List<Customer> searchCustomerMaster(String searchTerm) {

		String sql = "CALL search_customer_master(?)";
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, searchTerm);

		List<Customer> list = new ArrayList<>();

		for (Map<String, Object> row : rows) {

			Customer cust = new Customer();

			cust.setId((Integer) row.get("id"));
			cust.setCustCode((String) row.get("cust_code"));
			cust.setCustName((String) row.get("cust_name"));
			cust.setContactPerson((String) row.get("contact_person"));
			cust.setBranch((String) row.get("branch"));
			cust.setAddress1((String) row.get("address1"));
			cust.setAddress2((String) row.get("address2"));

			cust.setPinCode(row.get("pin_code") != null ? String.valueOf(row.get("pin_code")) : null);

			cust.setEmailId((String) row.get("email_id"));

			cust.setTelephone(row.get("telephone") != null ? ((Number) row.get("telephone")).longValue() : null);

			cust.setMobile(row.get("mobile") != null ? ((Number) row.get("mobile")).longValue() : null);

			cust.setFax((String) row.get("fax"));
			cust.setWebsite((String) row.get("website"));
			cust.setGstIn((String) row.get("gst_in"));
			cust.setRemarks((String) row.get("remarks"));

			cust.setUsername((String) row.get("username"));
			cust.setLoginBranch((String) row.get("login_branch"));
			cust.setSystemEntryDate(String.valueOf(row.get("system_entry_date")));

			cust.setCustomerTypeId((Integer) row.get("customer_type_id"));
			cust.setCityId((Integer) row.get("city_id"));
			cust.setStateId((Integer) row.get("state_id"));
			cust.setCountryId((Integer) row.get("country_id"));
			cust.setBranchId((Integer) row.get("branch_id"));
			cust.setLoginUserId((Integer) row.get("login_user_id"));

			list.add(cust);
		}

		return list;
	}

}
