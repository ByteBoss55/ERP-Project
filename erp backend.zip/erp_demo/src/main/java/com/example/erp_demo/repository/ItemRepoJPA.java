package com.example.erp_demo.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.erp_demo.entity.Item;
import com.example.erp_demo.projection.ItemMasterProjection;

@Repository
public interface ItemRepoJPA extends JpaRepository<Item, Integer> {

	@Procedure(procedureName = "master_item_master_generateNextItemCode")
    String generateNextItemCode();

    
    @Query(value = "CALL master_item_master_getAll()", nativeQuery = true)
    List<ItemMasterProjection> getAllItems();

}

    