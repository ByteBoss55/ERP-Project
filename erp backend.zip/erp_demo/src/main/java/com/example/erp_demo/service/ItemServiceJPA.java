package com.example.erp_demo.service;

import java.util.List;
import java.util.Optional;

import com.example.erp_demo.entity.Item;
import com.example.erp_demo.projection.ItemMasterProjection;

public interface ItemServiceJPA {

	// ================= READ (Stored Procedure / Projection) =================
    List<ItemMasterProjection> getAllItems();

    // ================= WRITE / CRUD (Entity) =================
    Item createItem(Item item);

    Optional<Item> getItemById(Integer id);

    Item updateItem(Integer id, Item updatedItem);

    void deleteItem(Integer id);

    Item saveItem(Item item);     // Save item with auto-generated code

    Item updateItemWithCode(int id, Item item);
    
}
