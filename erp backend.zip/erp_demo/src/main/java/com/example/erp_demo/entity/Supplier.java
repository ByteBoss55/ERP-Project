package com.example.erp_demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "supplier_master")
public class Supplier {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "supp_code", length = 255)
    private String suppCode;

    @Column(name = "supp_name", length = 255)
    private String suppName;

    @Column(name = "contact_person", length = 255)
    private String contactPerson;

    @Column(name = "branch", length = 255)
    private String branch;

    @Column(name = "address1", length = 255)
    private String address1;

    @Column(name = "address2", length = 255)
    private String address2;

    @Column(name = "pin_code", length = 255)
    private String pinCode;
    
    @Column(name = "email_id", length = 255)
    private String emailId;

    
	@Column(name = "telephone")
    private Long telephone;

    @Column(name = "mobile")
    private Long mobile;

    @Column(name = "fax", length = 255)
    private String fax;

    @Column(name = "website", length = 255)
    private String website;

    @Column(name = "gst_in", length = 255)
    private String gstIn;

    @Column(name = "remarks", length = 255)
    private String remarks;

    @Column(name = "username", length = 255)
    private String username;
    
    @Column(name = "login_branch", length = 255)
    private String loginBranch;

    @Column(name = "system_entry_date", length = 255)
    private String systemEntryDate;

    @Column(name = "supp_type_id")
    private Integer suppTypeId;

    @Column(name = "country_id")
    private Integer countryId;

    @Column(name = "state_id")
    private Integer stateId;

    @Column(name = "city_id")
    private Integer cityId;

    @Column(name = "branch_id")
    private Integer branchId;

    @Column(name = "login_user_id")
    private Integer loginUserId;
    
    private String country_name;
    private String state_name;
    private String city_name;
    private String branch_name;
    private String user_name;
    private String supp_type;

    public String getcountryName() {
		return country_name;
	}

	public void setcountryName(String country_name) {
		this.country_name = country_name;
	}

	public String getstateName() {
		return state_name;
	}

	public void setstateName(String state_name) {
		this.state_name = state_name;
	}

	public String getcityName() {
		return city_name;
	}

	public void setcityName(String city_name) {
		this.city_name = city_name;
	}

	public String getbranchName() {
		return branch_name;
	}

	public void setbranchName(String branch_name) {
		this.branch_name = branch_name;
	}

	public String getuserName() {
		return user_name;
	}

	public void setuserName(String user_name) {
		this.user_name = user_name;
	}

	public String getsuppType() {
		return supp_type;
	}

	public void setsuppType(String supp_type) {
		this.supp_type = supp_type;
	}

	// Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSuppCode() {
        return suppCode;
    }

    public void setSuppCode(String suppCode) {
        this.suppCode = suppCode;
    }

    public String getSuppName() {
        return suppName;
    }

    public void setSuppName(String suppName) {
        this.suppName = suppName;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public Long getTelephone() {
        return telephone;
    }

    public void setTelephone(Long telephone) {
        this.telephone = telephone;
    }

    public Long getMobile() {
        return mobile;
    }

    public void setMobile(Long mobile) {
        this.mobile = mobile;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getGstIn() {
        return gstIn;
    }

    public void setGstIn(String gstIn) {
        this.gstIn = gstIn;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
    
    public String getLoginBranch() {
		return loginBranch;
	}

	public void setLoginBranch(String loginBranch) {
		this.loginBranch = loginBranch;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSystemEntryDate() {
        return systemEntryDate;
    }

    public void setSystemEntryDate(String systemEntryDate) {
        this.systemEntryDate = systemEntryDate;
    }

    public Integer getSuppTypeId() {
        return suppTypeId;
    }

    public void setSuppTypeId(Integer suppTypeId) {
        this.suppTypeId = suppTypeId;
    }

    public Integer getCountryId() {
        return countryId;
    }

    public void setCountryId(Integer countryId) {
        this.countryId = countryId;
    }

    public Integer getStateId() {
        return stateId;
    }

    public void setStateId(Integer stateId) {
        this.stateId = stateId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Integer getBranchId() {
        return branchId;
    }

    public void setBranchId(Integer branchId) {
        this.branchId = branchId;
    }

    public Integer getLoginUserId() {
        return loginUserId;
    }

    public void setLoginUserId(Integer loginUserId) {
        this.loginUserId = loginUserId;
    }
    public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
