package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "unit_master")
public class UnitMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer unit_id;

    @Column(name = "unit_name", length = 100)
    private String unit_name;

    public Integer getUnitId() {
        return unit_id;
    }

    public void setUnitId(Integer unitId) {
        this.unit_id = unitId;
    }

    public String getUnitName() {
        return unit_name;
    }

    public void setUnitName(String unitName) {
        this.unit_name = unitName;
    }
}
