package com.example.erp_demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.MachineVsCheckPoint;
import com.example.erp_demo.repository.MachineVsCheckPointRepo;

@Service
public class MachineVsCheckPointService {

	@Autowired
    private MachineVsCheckPointRepo repo;
	
	public MachineVsCheckPoint create(MachineVsCheckPoint machine) {
        Long id = repo.create(machine);
        machine.setId(id.intValue());
        return machine;
    }
	
	public List<MachineVsCheckPoint> getAllMachineVsCheckPoints() {
        return repo.getAllMachineVsCheckPoint();
    }
	
	public MachineVsCheckPoint getMachineVsCheckPointById(Integer id) {
        return repo.getByIdMachineVsCheckPoint(id);
    }
	
	public boolean updateMachineVsCheckPoint(MachineVsCheckPoint machine) {
        return repo.update(machine);
    }
	
	public boolean deleteMachineVsCheckPoint(Integer id) {
        return repo.delete(id);
    }
}
