package com.example.erp_demo.repository;

import com.example.erp_demo.entity.AdminLoginRollMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminLoginRollRepository extends JpaRepository<AdminLoginRollMaster, Integer> {
}
