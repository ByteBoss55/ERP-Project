package com.example.erp_demo.entity;
 
import com.fasterxml.jackson.annotation.JsonProperty;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id; 
import jakarta.persistence.Table;

@Entity
@Table(name = "country_master")
public class Country {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "country_id")
	    @JsonProperty("id")
	    private Integer countryId;

	    @Column(name = "country_name", length = 250)
	    @JsonProperty("name")
	    private String countryName;

	     


	    // Getters & Setters
	    public Integer getCountryId() {
	        return countryId;
	    }
	    public void setCountryId(Integer countryId) {
	        this.countryId = countryId;
	    }

	    public String getCountryName() {
	        return countryName;
	    }
	    public void setCountryName(String countryName) {
	        this.countryName = countryName;
	    }

	     
	}

