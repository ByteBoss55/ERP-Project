package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
public class AdminLoginUserMaster {

	@Id
	int login_user_id;
	String user_name;
	String password;
	boolean is_active;
	int roleid;
	int employee_id;
	int branch_id;
	String system_entry_date;
	Boolean is_loggedin;
	private String employeeName;
	String emp_code;

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmp_code() {
		return emp_code;
	}

	public void setEmp_code(String emp_code) {
		this.emp_code = emp_code;
	}

	public AdminLoginUserMaster(int login_user_id, String user_name, String password, boolean is_active, int roleid,
			int employee_id, int branch_id, String system_entry_date, Boolean is_loggedin, String emp_code) {
		super();
		this.login_user_id = login_user_id;
		this.user_name = user_name;
		this.password = password;
		this.is_active = is_active;
		this.roleid = roleid;
		this.employee_id = employee_id;
		this.branch_id = branch_id;
		this.system_entry_date = system_entry_date;
		this.is_loggedin = is_loggedin;
		this.emp_code = emp_code;
	}

	public AdminLoginUserMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getLogin_user_id() {
		return login_user_id;
	}

	public void setLogin_user_id(int login_user_id) {
		this.login_user_id = login_user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isIs_active() {
		return is_active;
	}

	public void setIs_active(boolean is_active) {
		this.is_active = is_active;
	}

	public int getRoleid() {
		return roleid;
	}

	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}

	public int getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}

	public int getBranch_id() {
		return branch_id;
	}

	public void setBranch_id(int branch_id) {
		this.branch_id = branch_id;
	}

	public String getSystem_entry_date() {
		return system_entry_date;
	}

	public void setSystem_entry_date(String system_entry_date) {
		this.system_entry_date = system_entry_date;
	}

	public Boolean getIs_loggedin() {
		return is_loggedin;
	}

	public void setIs_loggedin(Boolean is_loggedin) {
		this.is_loggedin = is_loggedin;
	}

	@Override
	public String toString() {
		return "AdminLoginUserMaster [login_user_id=" + login_user_id + ", user_name=" + user_name + ", password="
				+ password + ", is_active=" + is_active + ", roleid=" + roleid + ", employee_id=" + employee_id
				+ ", branch_id=" + branch_id + ", system_entry_date=" + system_entry_date + ", is_loggedin="
				+ is_loggedin + "]";
	}
}