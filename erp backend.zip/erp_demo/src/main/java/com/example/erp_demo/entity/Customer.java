package com.example.erp_demo.entity;

 
import jakarta.persistence.Entity;
 
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "customer_master")
public class Customer {

	@Id
	private Integer id;

	// -------- Main Table Fields --------
	private String custCode;
	private String custName;
	private String contactPerson;
	private String branch;
	private String address1;
	private String address2;
	private String pinCode;
	private String emailId;
	private long telephone;
	private long mobile;
	private String fax;
	private String website;
	private String gstIn;
	private String remarks;
	private String username;
	private String loginBranch;
	private String systemEntryDate;

	private Integer customerTypeId;
	private Integer countryId;
	private Integer stateId;
	private Integer cityId;
	private Integer branchId;
	private Integer loginUserId;

	// -------- Joined / Display Fields --------
	@Transient
	private String country_name;
	
	@Transient
	private String state_name;
	@Transient
	private String city_name;
	@Transient
	private String branch_name;
	@Transient
	private String customer_type;
	@Transient
	private String user_name;

	// -------- Getters & Setters --------

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustCode() {
		return custCode;
	}

	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getTelephone() {
		return telephone;
	}

	public void setTelephone(long telephone) {
		this.telephone = telephone;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getGstIn() {
		return gstIn;
	}

	public void setGstIn(String gstIn) {
		this.gstIn = gstIn;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLoginBranch() {
		return loginBranch;
	}

	public void setLoginBranch(String loginBranch) {
		this.loginBranch = loginBranch;
	}

	public String getSystemEntryDate() {
		return systemEntryDate;
	}

	public void setSystemEntryDate(String systemEntryDate) {
		this.systemEntryDate = systemEntryDate;
	}

	public Integer getCustomerTypeId() {
		return customerTypeId;
	}

	public void setCustomerTypeId(Integer customerTypeId) {
		this.customerTypeId = customerTypeId;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public Integer getCityId() {
		return cityId;
	}
 

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public Integer getBranchId() {
		return branchId;
	}

	public void setBranchId(Integer branchId) {
		this.branchId = branchId;
	}

	public Integer getLoginUserId() {
		return loginUserId;
	}

	public void setLoginUserId(Integer loginUserId) {
		this.loginUserId = loginUserId;
	}

	public String getCountryName() {
		return country_name;
	}

	public void setCountryName(String country_name) {
		this.country_name = country_name;
	}

	public String getStateName() {
		return state_name;
	}

	public void setStateName(String state_name) {
		this.state_name = state_name;
	}

	public String getCityName() {
		return city_name;
	}

	public void setCityName(String city_name) {
		this.city_name = city_name;
	}

	public String getBranchName() {
		return branch_name;
	}

	public void setBranchName(String branch_name) {
		this.branch_name = branch_name;
	}

	public String getUserName() {
		return user_name;
	}

	public void setUserName(String user_name) {
		this.user_name = user_name;
	}

	public String getCustomerName() {
		return customer_type;
	}

	 
	public String getCustomer_type() {
		return customer_type;
	}

	public void setCustomer_type(String customer_type) {
		this.customer_type = customer_type;
	}

}
