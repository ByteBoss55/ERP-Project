package com.example.erp_demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import com.example.erp_demo.entity.Customer;
import com.example.erp_demo.projection.CustomerMasterProjection;
import com.example.erp_demo.projection.ItemMasterProjection;
 

public interface CustomerRepoJPA extends JpaRepository<Customer, Long>{
	
	 @Procedure(procedureName = "master_customer_master_generateNextCustCode")
	    String generateNextCustomerCode();
	
	
	Optional<Customer> findByCustCode(String custCode);

   List<Customer> findByCustNameContainingIgnoreCase(String name);
   
   @Query(value = "CALL master_customer_master_getAll()", nativeQuery = true)
   List<CustomerMasterProjection> getAllCustomers();
}
