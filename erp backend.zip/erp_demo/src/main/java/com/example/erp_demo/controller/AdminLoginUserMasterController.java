package com.example.erp_demo.controller;
 

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.jwt.JwtUtil;
import com.example.erp_demo.service.AdminLoginUserMasterService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class AdminLoginUserMasterController {
	
	@Autowired
	 AdminLoginUserMasterService adminloginusermasterservice;
	
	@Autowired
    private JwtUtil jwtUtil;
	
	@GetMapping("authenticateAdminUser1/{username}/{password}")
	public ResponseEntity<Map<String, Object>> authenticateAdminUser1(
	    @PathVariable String username, @PathVariable String password) {
		System.out.println("username " +username);
		System.out.println("password " +password);
	    Map<String, Object> response = new HashMap<>();
	    Map<String, Object> resultMap = adminloginusermasterservice.authenticateAdminUser1(username, password);

	    if (!resultMap.isEmpty() && resultMap.containsKey("login_user_id")) {
	    	String token = jwtUtil.generateToken(username);
	        response.put("status", "success");
	        response.put("data", resultMap);
	        response.put("token", token);
	    } else {
	        response.put("status", "error");
	        response.put("message", "Invalid username or password.");
	    }

	    return ResponseEntity.ok(response);
	}

	 @PostMapping("/logoutAdminUser/{loginUserId}")
     public ResponseEntity<String> logoutAdminUser(@PathVariable int loginUserId) {
         try {
       	  adminloginusermasterservice.logoutAdminUser(loginUserId);
             return ResponseEntity.ok("User logged out successfully");
         } catch (Exception e) {
             return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error logging out user");
         }
     }
}
