package com.example.erp_demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.entity.Machine;
import com.example.erp_demo.service.MachineService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class MachineController {

	@Autowired
    private MachineService service;

    @PostMapping("/savemachine")
    public ResponseEntity<Machine> create(@RequestBody Machine machine) {
        return ResponseEntity.ok(service.create(machine));
    }

    @GetMapping("/getAllMachines")
    public List<Machine> getAllMachines() {
        return service.getAllMachines();
    }

    @GetMapping("/getMachineById/{id}")
    public ResponseEntity<?> getMachineById(@PathVariable Integer id) {
        Machine machine = service.getMachineById(id);
        if (machine == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Machine with ID " + id + " not found.");
        } else {
            return ResponseEntity.ok(machine);
        }
    }

    @PutMapping("/updatemachine")
    public ResponseEntity<String> updateMachine(@RequestBody Machine machine) {
        boolean updated = service.updateMachine(machine);
        return updated
                ? ResponseEntity.ok("Machine updated successfully.")
                : ResponseEntity.status(500).body("Failed to update machine.");
    }

    @DeleteMapping("/deletemachine/{id}")
    public ResponseEntity<String> deleteMachine(@PathVariable Integer id) {
        boolean deleted = service.deleteMachine(id);
        return deleted
                ? ResponseEntity.ok("Machine deleted successfully.")
                : ResponseEntity.status(500).body("Failed to delete machine.");
    }
}
