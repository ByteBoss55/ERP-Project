package com.example.erp_demo.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate; 
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.entity.Item;
import com.example.erp_demo.projection.ItemMasterProjection;
import com.example.erp_demo.service.ItemService;
import com.example.erp_demo.service.ItemServiceJPA;

@RestController
@CrossOrigin(origins = "http://localhost:3000")

public class ItemController {

    @Autowired
    private ItemService service;
  
    // CREATE ITEM
    @PostMapping("/saveitem")
    public ResponseEntity<Integer> create(@RequestBody Item item){
        return ResponseEntity.ok(service.saveItem(item));
    }

    // GET ALL ITEMS
    @GetMapping("/getallitems")
    public List<Item> getAllItems() {
        return service.getAllItems();
    }

    // GET ITEM BY ID
    @GetMapping("/getitembyid/{id}")
    public ResponseEntity<?> getItem(@PathVariable Integer id) {
        Item item = service.getItemById(id);

        if (item == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Item with ID " + id + " not found");
        }

        return ResponseEntity.ok(item);
    }

    // UPDATE ITEM
    @PutMapping("/updateitem/{id}")
    public ResponseEntity<?> updateItem(@PathVariable Integer id, @RequestBody Item item) {

    	item.setId(id);
        boolean updated = service.updateItemById(id, item);

        if (updated) {
            return ResponseEntity.ok("Item updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to update item.");
        }
    }

    // DELETE ITEM
    @DeleteMapping("/deleteitem/{id}")
    public ResponseEntity<String> deleteItem(@PathVariable Integer id) {

        boolean deleted = service.deleteItem(id);

        if (deleted) {
            return ResponseEntity.ok("Item deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to delete item.");
        }
    }

    // ➤ GET NEXT ITEM CODE (AUTO-GENERATED)
    @GetMapping("nextitemcode")
    public ResponseEntity<String> getNextItemCode() {
        String nextCode = service.generateNextItemCode();
        return ResponseEntity.ok(nextCode);
    }
    
   
	@GetMapping("/searchItemMaster/{searchTerm}")
	public ResponseEntity<List<Item>> search(@PathVariable String searchTerm) {
		return ResponseEntity.ok(service.search(searchTerm));
	}

 
    //----------------------------------------------------------------------------------------------------------------------------------------------
    
    // ✅ Endpoint to save item (auto-generates itemCode using stored procedure)

   @Autowired
    private ItemServiceJPA itemService;

    // ✅ Endpoint to save item (auto-generates itemCode using stored procedure)
   @GetMapping("/nextitemcodebyjpa")
   public ResponseEntity<String> generateNextItemCode() {
       return ResponseEntity.ok(service.generateNextItemCode());
   }

    
    @PutMapping("/updategenerateNextItemCode/{id}")
    public ResponseEntity<?> updateItem
    (@PathVariable int id,
     @RequestBody Item item) {
    	Item updated = itemService.updateItemWithCode(id, item);
    
     return ResponseEntity.ok(updated);
    } 
    
    @PostMapping("/saveItemJPA")
    public ResponseEntity<Item> createItemJPA(@RequestBody Item item) {
        Item savedItem = itemService.createItem(item);
        return ResponseEntity.ok(savedItem);
    }

    @GetMapping("/getAllItemsJPA")
    public ResponseEntity<List<ItemMasterProjection>> getAllItemsJPA() {
    List<ItemMasterProjection> items = itemService.getAllItems();
    return ResponseEntity.ok(items);
    }

    @GetMapping("/getItemByIdJPA/{id}")
    public ResponseEntity<?> getItemByIdJPA(@PathVariable Integer id) {

        Optional<Item> item = itemService.getItemById(id);

        if (item.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Item with ID " + id + " not found.");
        }

        return ResponseEntity.ok(item.get());
    }

    @PutMapping("/updateItemByJPA/{id}")
    public ResponseEntity<?> updateItemJPA(@PathVariable Integer id){
    	try {
    		itemService.updateItem(id, null);
    		return ResponseEntity.ok("Item with ID " + "updated successfully.");
    	} catch (RuntimeException ex) {
    		return ResponseEntity.status(HttpStatus.NOT_FOUND)
    				.body(ex.getMessage());
    	}
    }
    
    @DeleteMapping("/deleteItemJPA/{id}")
    public ResponseEntity<?> deleteItemJPA(@PathVariable Integer id) {

        try {
            itemService.deleteItem(id);
            return ResponseEntity.ok("Item with ID " + id + " deleted successfully.");
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ex.getMessage());
        }
    }

}