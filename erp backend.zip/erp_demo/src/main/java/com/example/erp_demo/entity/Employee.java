package com.example.erp_demo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;

@Entity
@Table(name = "employee_master")
public class Employee {

	/* ================= PRIMARY KEY ================= */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "e_sr_no")
	private Integer e_sr_no;

	/* ================= BASIC INFO ================= */
	@Column(name = "emp_code")
	private String empCode;

	@Column(name = "title", length = 10)
	private String title;

	@Column(name = "first_name", length = 30)
	private String firstName;

	@Column(name = "middle_name", length = 15)
	private String middleName;

	@Column(name = "last_name", length = 15)
	private String lastName;

	@Column(name = "dob")
	private String dob;

	/* ================= CONTACT ================= */
	@Column(name = "contact_no", length = 10)
	private String contactNo;

	@Column(name = "mobile_no", length = 20)
	private String mobileNo;

	@Column(name = "email_id", length = 255)
	private String emailId;

	/* ================= IDS (FKs) ================= */
	@Column(name = "gid")
	private Integer gId;

	@Column(name = "blood_group_id")
	private Integer bloodGroupId;

	@Column(name = "msid")
	private Integer msId;

	@Column(name = "designation_id")
	private Integer designationId;

	@Column(name = "qualification_id")
	private Integer qualificationId;

	@Column(name = "unit_id")
	private Integer unitId;

	@Column(name = "contractor_id")
	private Integer contractorId;

	@Column(name = "pay_type_id")
	private Integer payTypeId;

	/* ================= SALARY ================= */
	@Column(name = "ctc")
	private Integer ctc;

	@JsonProperty("gross_amount")
	private Integer grossAmount;

	@Column(name = "balance")
	private Integer balance;

	/* ================= ADDRESS ================= */
	@Column(name = "temp_address", length = 200)
	private String tempAddress;

	@Column(name = "permanent_address", length = 255)
	private String permanentAddress;

	/* ================= DOCUMENTS ================= */
	@Column(name = "pan_no", length = 30)
	private String panNo;

	@Column(name = "aadhar_no")
	private int aadharNo;

	@Column(name = "pfacc_no", length = 50)
	@JsonProperty("pfacc_no")
	private String pfacc_no;

	public String getPfacc_no() {
		return pfacc_no;
	}

	public void setPfacc_no(String pfacc_no) {
		this.pfacc_no = pfacc_no;
	}

	@Column(name = "esic_acc_no", length = 30)
	private String esicAccNo;

	/* ================= STATUS ================= */
	@Column(name = "is_left")
	private String isLeft;

	@Column(name = "left_date")
	private String leftDate;

	/* ================= LOCATION ================= */
	@Column(name = "city_id")
	private Integer cityId;

	@Column(name = "state_id")
	private Integer stateId;

	@Column(name = "country_id")
	private Integer countryId;

	/* ================= TRANSIENT (DISPLAY ONLY) ================= */
	@Transient
	private String gender;
	@Transient
	private String blood_group;
	@Transient
	private String marital_status;
	@Transient
	private String designation_name;
	@Transient
	private String qualification_name;
	@Transient
	private String country_name;
	@Transient
	private String state_name;
	@Transient
	private String city_name;
	@Transient
	private String leave_name;
	@Transient
	private String d_name;
	@Transient
	private String unit_name;
	@Transient
	private String category_name;
	@Transient
	private String week_off;
	@Transient
	private String contractor_name;
	@Transient
	private String type_of_staff;
	@Transient
	private String pay_type_name;
	@Transient
	private String company_name;
	@Transient
	private String cid;
	@Transient
	private String document_name;
	@Transient
	private String training_details;
	@Transient
	private String auto_mail;
	@Transient
	private int leave_id;
	@Transient
	private String emp_photo;
	@Transient
	private String date_of_join;
	@Transient
	private int did;
	@Transient
	private int category_id;
	@Transient
	private int wid;
	@Transient
	private int staff_id;
	@Transient
	private String asset;
	@Transient
	private String apprasal_history;
	@Transient
	private int attendance_id;
	

	/* ================= CONSTRUCTOR ================= */
	public Employee() {
	}

	public String getDocument_name() {
		return document_name;
	}

	public void setDocument_name(String document_name) {
		this.document_name = document_name;
	}

	public String getTraining_details() {
		return training_details;
	}

	public void setTraining_details(String training_details) {
		this.training_details = training_details;
	}

	public String getAuto_mail() {
		return auto_mail;
	}

	public void setAuto_mail(String auto_mail) {
		this.auto_mail = auto_mail;
	}

	public int getLeave_id() {
		return leave_id;
	}

	public void setLeave_id(int leave_id) {
		this.leave_id = leave_id;
	}

	public String getEmp_photo() {
		return emp_photo;
	}

	public void setEmp_photo(String emp_photo) {
		this.emp_photo = emp_photo;
	}

	public String getDate_of_join() {
		return date_of_join;
	}

	public void setDate_of_join(String date_of_join) {
		this.date_of_join = date_of_join;
	}

	public int getDid() {
		return did;
	}

	public void setDid(int did) {
		this.did = did;
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public int getWid() {
		return wid;
	}

	public void setWid(int wid) {
		this.wid = wid;
	}

	public int getStaff_id() {
		return staff_id;
	}

	public void setStaff_id(int staff_id) {
		this.staff_id = staff_id;
	}

	public String getAsset() {
		return asset;
	}

	public void setAsset(String asset) {
		this.asset = asset;
	}

	public String getApprasal_history() {
		return apprasal_history;
	}

	public void setApprasal_history(String apprasal_history) {
		this.apprasal_history = apprasal_history;
	}

	public Integer getESrNo() {
		return e_sr_no;
	}

	public void setESrNo(Integer eSrNo) {
		this.e_sr_no = eSrNo;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Integer getgId() {
		return gId;
	}

	public void setgId(Integer gId) {
		this.gId = gId;
	}

	public Integer getBloodGroupId() {
		return bloodGroupId;
	}

	public void setBloodGroupId(Integer bloodGroupId) {
		this.bloodGroupId = bloodGroupId;
	}

	public Integer getMsId() {
		return msId;
	}

	public void setMsId(Integer msId) {
		this.msId = msId;
	}

	public Integer getDesignationId() {
		return designationId;
	}

	public void setDesignationId(Integer designationId) {
		this.designationId = designationId;
	}

	public Integer getQualificationId() {
		return qualificationId;
	}

	public void setQualificationId(Integer qualificationId) {
		this.qualificationId = qualificationId;
	}

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public Integer getContractorId() {
		return contractorId;
	}

	public void setContractorId(Integer contractorId) {
		this.contractorId = contractorId;
	}

	public Integer getPayTypeId() {
		return payTypeId;
	}

	public void setPayTypeId(Integer payTypeId) {
		this.payTypeId = payTypeId;
	}

	public Integer getCtc() {
		return ctc;
	}

	public void setCtc(Integer ctc) {
		this.ctc = ctc;
	}

	public Integer getGrossAmount() {
		return grossAmount;
	}

	public void setGrossAmount(Integer grossAmount) {
		this.grossAmount = grossAmount;
	}

	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public String getTempAddress() {
		return tempAddress;
	}

	public void setTempAddress(String tempAddress) {
		this.tempAddress = tempAddress;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public int getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(int aadharNo) {
		this.aadharNo = aadharNo;
	}


	public String getEsicAccNo() {
		return esicAccNo;
	}

	public void setEsicAccNo(String esicAccNo) {
		this.esicAccNo = esicAccNo;
	}

	public String getIsLeft() {
		return isLeft;
	}

	public void setIsLeft(String isLeft) {
		this.isLeft = isLeft;
	}

	public String getLeftDate() {
		return leftDate;
	}

	public void setLeftDate(String leftDate) {
		this.leftDate = leftDate;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBloodGroup() {
		return blood_group;
	}

	public void setBloodGroup(String bloodGroup) {
		this.blood_group = bloodGroup;
	}

	public String getMarital_status() {
		return marital_status;
	}

	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}

	public String getDesignation_name() {
		return designation_name;
	}

	public void setDesignation_name(String designation_name) {
		this.designation_name = designation_name;
	}

	public String getQualification_name() {
		return qualification_name;
	}

	public void setQualification_name(String qualification_name) {
		this.qualification_name = qualification_name;
	}

	public String getCountry_name() {
		return country_name;
	}

	public void setCountry_name(String country_name) {
		this.country_name = country_name;
	}

	public String getState_name() {
		return state_name;
	}

	public void setState_name(String state_name) {
		this.state_name = state_name;
	}

	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}

	public String getLeave_name() {
		return leave_name;
	}

	public void setLeave_name(String leave_name) {
		this.leave_name = leave_name;
	}

	public String getD_name() {
		return d_name;
	}

	public void setD_name(String d_name) {
		this.d_name = d_name;
	}

	public String getUnit_name() {
		return unit_name;
	}

	public void setUnit_name(String unit_name) {
		this.unit_name = unit_name;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public String getWeek_off() {
		return week_off;
	}

	public void setWeek_off(String week_off) {
		this.week_off = week_off;
	}

	public String getContractor_name() {
		return contractor_name;
	}

	public void setContractor_name(String contractor_name) {
		this.contractor_name = contractor_name;
	}

	public int getAttendance_id() {
		return attendance_id;
	}

	public void setAttendance_id(int attendance_id) {
		this.attendance_id = attendance_id;
	}

	public String getType_of_staff() {
		return type_of_staff;
	}

	public void setType_of_staff(String type_of_staff) {
		this.type_of_staff = type_of_staff;
	}

	public String getPay_type_name() {
		return pay_type_name;
	};

	public void setPay_type_name(String pay_type_name) {
		this.pay_type_name = pay_type_name;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getDateOfBirth() {
		// TODO Auto-generated method stub
		return date_of_join;
	}

	
}
