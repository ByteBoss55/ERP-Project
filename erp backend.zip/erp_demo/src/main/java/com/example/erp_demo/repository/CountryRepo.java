package com.example.erp_demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.erp_demo.entity.Country;
 
public interface CountryRepo extends JpaRepository<Country, Integer>{

}
