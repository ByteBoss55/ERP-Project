package com.example.erp_demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Employee;
import com.example.erp_demo.entity.Item;
import com.example.erp_demo.repository.EmployeeRepo;

@Service
public class EmployeeService {
	
	    @Autowired
	    private EmployeeRepo repo;
	    
		public int saveEmployee(Employee employee) {
			// Step 1: Generate next item code
	        String nextCode = repo.generateNextEmpCode();
	        employee.setEmpCode(nextCode);

	        // Step 2: Save item using your existing create() method
	        return repo.create(employee);
	        
		}
	     
	    public Employee create(Employee employee) {
	        Integer eSrNo = repo.create(employee);
	        employee.setESrNo(eSrNo.intValue());
	        return employee;
	    }

	    // ---------- READ ALL ----------
	    public List<Employee> getAllEmployees() {
	        return repo.getAllEmployees();
	    }

	    // ---------- READ BY ID ----------
	    public Employee getEmployeeById(Integer eSrNo) {
	        return repo.getEmployeeById(eSrNo);
	    }

	    // ---------- UPDATE ----------
	    public boolean updateEmployee(Integer eSrNo, Employee employee) {
	    	return repo.updateEmployee(employee);
	    }

	    // ---------- DELETE ----------
	    public boolean deleteEmployee(Integer eSrNo) {
	        return repo.deleteEmployee(eSrNo);
	    }
	    
	    public String generateNextEmpCode() {
			// TODO Auto-generated method stub
			return repo.generateNextEmpCode();
		}
		
}
