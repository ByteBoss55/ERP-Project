package com.example.erp_demo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.*;

@Entity
@Table(name = "sub_category_master")
public class SubCategoryMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonProperty("sub_category_id")
    private Integer sub_category_id;

    @Column(name = "sub_category_name", length = 255)
    @JsonProperty("sub_category_name")
    private String subCategoryName;
 
    @JsonProperty("sub_category_id")
    public Integer getId() {
        return sub_category_id;
    }

    public void setId(Integer id) {
        this.sub_category_id = id;
    }

    @JsonProperty("sub_category_name")
    public String getSubCategoryName() {
        return subCategoryName;
    }

    public void setSubCategoryName(String subCategoryName) {
        this.subCategoryName = subCategoryName;
    }

    
}
