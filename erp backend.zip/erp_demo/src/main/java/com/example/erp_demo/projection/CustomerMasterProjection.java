package com.example.erp_demo.projection;

public interface CustomerMasterProjection {

	Integer getId();

	String getCustCode();
	String getCustName();
	String getContactPerson();
	String getBranch();
	String getAddress1();
	String getAddress2();
	String getPinCode();
	String getEmailId();
	Long getTelephone();
	Long getMobile();
	String getFax();
	String getWebsite();
	String getGstIn();
	String getRemarks();
	String getUsername();
	String getLoginBranch();
	String getSystemEntryDate();

	Integer getCustomerTypeId();
	Integer getCountryId();
	Integer getStateId();
	Integer getCityId();
	Integer getBranchId();
	Integer getLoginUserId();

	// JOINED VALUES
	String getCountryName();
	String getStateName();
	String getCityName();
	String getBranchName();
	String getCustomerType();
	String getUserName();

}
