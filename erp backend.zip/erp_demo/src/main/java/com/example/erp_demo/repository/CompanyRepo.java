package com.example.erp_demo.repository;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.erp_demo.entity.Company;

@Repository
public class CompanyRepo {

	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	public Long create(Company company) {
		return jdbcTemplate.execute(
		  (CallableStatementCreator) connection -> {
	        	CallableStatement cs = connection.prepareCall("{CALL insert_company(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
	            cs.setString(1, company.getCompanyName());
	            cs.setString(2, company.getAddress1());
	            cs.setString(3, company.getAddress2());
	            cs.setInt(4, company.getCityId());
	            cs.setInt(5, company.getStateId());
	            cs.setInt(6, company.getCountryId());
	            cs.setString(7, company.getPinCode());
	            cs.setString(8, company.getEmailId());
	            cs.setString(9, company.getTelephone());
	            cs.setString(10, company.getMobile());
	            cs.setString(11, company.getContactPerson());
	            cs.setString(12, company.getWebsite());
	            cs.setString(13, company.getGstIn());
	            cs.setString(14, company.getSystemDate());	           
	            cs.registerOutParameter(15, Types.BIGINT); 
	          
	            return cs;
	        },
	        (CallableStatementCallback<Long>) cs -> {
	            cs.execute();
	            return cs.getLong(15); // return generated company id
	        }
	    );
	}
	
	public List<Company> getAllCompanies() {
	    return jdbcTemplate.execute((ConnectionCallback<List<Company>>) con -> {
	        try (var cs = con.prepareCall("{CALL get_all_companies()}")) {
	            List<Company> list = new ArrayList<>();
	            try (ResultSet rs = cs.executeQuery()) {
	                while (rs.next()) {
	                    Company company = new Company();
	                    company.setId(rs.getInt("id"));
	                    company.setCompanyName(rs.getString("company_name"));
	                    company.setAddress1(rs.getString("address1"));
	                    company.setAddress2(rs.getString("address2"));
	                    company.setCityId(rs.getInt("city_id"));
	                    company.setStateId(rs.getInt("state_id"));
	                    company.setCountryId(rs.getInt("country_id"));
	                    company.setPinCode(rs.getString("pin_code"));
	                    company.setEmailId(rs.getString("email_id"));
	                    company.setTelephone(rs.getString("telephone"));
	                    company.setMobile(rs.getString("mobile"));
	                    company.setContactPerson(rs.getString("contact_person"));
	                    company.setWebsite(rs.getString("website"));
	                    company.setGstIn(rs.getString("gst_in"));
	                    company.setSystemDate(rs.getString("system_date"));
	                    list.add(company);
	                }
	            }
	            return list;
	        }
	    });
	}

	public Company getCompanyById(Integer id) {
	    return jdbcTemplate.execute((ConnectionCallback<Company>) con -> {
	        try (var cs = con.prepareCall("{CALL get_company_by_id(?)}")) {
	            cs.setInt(1, id);
	            try (ResultSet rs = cs.executeQuery()) {
	                if (rs.next()) {
	                    Company company = new Company();
	                    company.setId(rs.getInt("id"));
	                    company.setCompanyName(rs.getString("company_name"));
	                    company.setAddress1(rs.getString("address1"));
	                    company.setAddress2(rs.getString("address2"));
	                    company.setCityId(rs.getInt("city_id"));
	                    company.setStateId(rs.getInt("state_id"));
	                    company.setCountryId(rs.getInt("country_id"));
	                    company.setPinCode(rs.getString("pin_code"));
	                    company.setEmailId(rs.getString("email_id"));
	                    company.setTelephone(rs.getString("telephone"));
	                    company.setMobile(rs.getString("mobile"));
	                    company.setContactPerson(rs.getString("contact_person"));
	                    company.setWebsite(rs.getString("website"));
	                    company.setGstIn(rs.getString("gst_in"));
	                    company.setSystemDate(rs.getString("system_date"));
	                    return company;
	                }
	            }
	        }
	        return null; 
	    });
	}

	public boolean updateCompany(Company company) {
	    String sql = "{CALL update_company(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

	    int rowsAffected = jdbcTemplate.update(connection -> {
	        var cs = connection.prepareCall(sql);
	        cs.setInt(1, company.getId());
	        cs.setString(2, company.getCompanyName());
	        cs.setString(3, company.getAddress1());
	        cs.setString(4, company.getAddress2());
	        cs.setInt(5, company.getCityId());
	        cs.setInt(6, company.getStateId());
	        cs.setInt(7, company.getCountryId());
	        cs.setString(8, company.getPinCode());
	        cs.setString(9, company.getEmailId());
	        cs.setString(10, company.getTelephone());
	        cs.setString(11, company.getMobile());
	        cs.setString(12, company.getContactPerson());
	        cs.setString(13, company.getWebsite());
	        cs.setString(14, company.getGstIn());
	        cs.setString(15, company.getSystemDate());
	        return cs;
	    });

	    return rowsAffected > 0;
	}

	public boolean deleteCompany(Integer id) {
	    String sql = "{CALL delete_company(?)}";

	    int rowsAffected = jdbcTemplate.update(connection -> {
	        var cs = connection.prepareCall(sql);
	        cs.setInt(1, id);
	        return cs;
	    });

	    return rowsAffected > 0;
	}

}