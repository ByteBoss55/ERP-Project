package com.example.erp_demo.repository;

import com.example.erp_demo.entity.MaritalStatusMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MaritalStatusRepository extends JpaRepository<MaritalStatusMaster, Integer> {
}

