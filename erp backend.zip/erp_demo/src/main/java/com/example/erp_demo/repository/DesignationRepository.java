package com.example.erp_demo.repository;

import com.example.erp_demo.entity.DesignationMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DesignationRepository extends JpaRepository<DesignationMaster, Integer> {
}

