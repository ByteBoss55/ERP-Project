package com.example.erp_demo.entity;

 

import jakarta.persistence.*;

@Entity
@Table(name = "admin_login_roll_master")
public class AdminLoginRollMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "roleid")
    private Integer roleId;

    @Column(name = "role_name", length = 100)
    private String roleName;

    @Column(name = "is_active")
    private Boolean isActive;

    public Integer getRoleId() { return roleId; }
    public void setRoleId(Integer roleId) { this.roleId = roleId; }

    public String getRoleName() { return roleName; }
    public void setRoleName(String roleName) { this.roleName = roleName; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
}

