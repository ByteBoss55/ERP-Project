package com.example.erp_demo.repository;

import com.example.erp_demo.entity.BloodGroupMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BloodGroupRepository extends JpaRepository<BloodGroupMaster, Integer> {
}
