package com.example.erp_demo.projection;

public interface ItemMasterProjection {

	
	Integer getId();
    String getItemCode();
    String getItemName();
    String getMaterial();
    String getItemType();
    String getItemSubType();
    String getHsnCode();
    Double getGstRate();
    Double getPurchaseCost();
    Double getSellingPrice();
    String getUsername();
    String getLoginBranch();
    String getSystemEntryDate();
    String getRawMaterial();

    Integer getSubCategoryId();
    Integer getManufacturerId();
    Integer getColourId();
    Integer getUnitId();
    Integer getBranchId();
    Integer getCategoryId();

    String getDrawingNo();
    String getSpecification();

    // JOINED VALUES
    String getColourName();
    String getUnitName();
    String getManufacturerName();
    String getCategoryName();
    String getSubCategoryName();
    String getBranchName();
}
