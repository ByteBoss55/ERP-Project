package com.example.erp_demo.jwt;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
@Order(1)
public abstract class JwtAuthFilter implements Filter  {
	private final JwtUtil jwtUtil;

    @Autowired
    public JwtAuthFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
    	HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        httpResponse.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
        httpResponse.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        httpResponse.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
        httpResponse.setHeader("Access-Control-Allow-Credentials", "true");

        // Allow preflight requests to pass through without JWT checks
        if ("OPTIONS".equalsIgnoreCase(httpRequest.getMethod())) {
        	httpResponse.setStatus(HttpServletResponse.SC_OK);
            return;
        }
    	
    	 
         String path = httpRequest.getRequestURI();
         boolean responseSentByFilter = false;

         try {
             // Define which paths are protected and require JWT validation
             if (!path.startsWith("/authenticateAdminUser1/")) {
                 String authHeader = httpRequest.getHeader("Authorization");
                 System.out.println(authHeader);
                 if (authHeader != null && authHeader.startsWith("Bearer ")) {
                     String token = authHeader.substring(7);
                     String username = jwtUtil.validateTokenAndGetUsername(token);
                     System.out.println(username);
                     if (username == null) {
                     	  httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid or expired JWT token.");
                           responseSentByFilter = true;
                     }
                 } else {
                     // Authorization header missing or not Bearer for a protected route
                     httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Authorization header is missing or not Bearer for protected resource.");
                     responseSentByFilter = true; // Mark that response is handled
                 }
             }

             // If the response was not sent by this filter (i.e., request is public or token was valid for protected)
             if (!responseSentByFilter) {
                 chain.doFilter(request, response);
             }
         } finally {

         }
    }
}
