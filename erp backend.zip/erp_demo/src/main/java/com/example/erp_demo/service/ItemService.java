package com.example.erp_demo.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Item;
import com.example.erp_demo.repository.ItemRepo;

@Service
public class ItemService {

	@Autowired
    private ItemRepo repo;
	
	public int saveItem(Item item) {
		// Step 1: Generate next item code
        String nextCode = repo.generateNextItemCode();
        item.setItemCode(nextCode);

        // Step 2: Save item using your existing create() method
        return repo.create(item);
    }
    public List<Item> getAllItems() {
    	return repo.getAllItems();
    }
    public Item getItemById(Integer id) {
    	return repo.getItemById(id);
    }
   
    public boolean updateItemById(Integer id, Item item) {
    	return repo.updateItem(item);
    }
    public boolean deleteItem(Integer id) {
    	return repo.deleteItem(id);
    }
	public String generateNextItemCode() {
		// TODO Auto-generated method stub
		return repo.generateNextItemCode();
	}
	
	public List<Item> search(String term) {
        return repo.searchItemMaster(term);
    }
 
}
	
