package com.example.erp_demo.repository;

import com.example.erp_demo.entity.DepartmentMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<DepartmentMaster, Integer> {
}
