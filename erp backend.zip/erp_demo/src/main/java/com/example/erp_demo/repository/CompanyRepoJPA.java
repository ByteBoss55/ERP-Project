package com.example.erp_demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.erp_demo.entity.Company;

@Repository
public interface CompanyRepoJPA extends JpaRepository<Company, Long>{

	

}
