package com.example.erp_demo.repository;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.erp_demo.entity.Machine;

@Repository
public class MachineRepo {

	 @Autowired
	    private JdbcTemplate jdbcTemplate;

	     
	    public Long create(Machine machine) {
	        return jdbcTemplate.execute(
	            (CallableStatementCreator) connection -> {
	                CallableStatement cs = connection.prepareCall("{CALL insert_machine(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
	                cs.setString(1, machine.getCmpCode());
	                cs.setString(2, machine.getGrp());
	                cs.setString(3, machine.getCategoryCode());
	                cs.setString(4, machine.getMachineNo());
	                cs.setString(5, machine.getMachineName());
	                cs.setString(6, machine.getMake());
	                cs.setString(7, machine.getModel());
	                cs.setString(8, machine.getPmPlan());
	                cs.setDouble(9, machine.getCapacityRangeFrom() != null ? machine.getCapacityRangeFrom() : 0.0);
	                cs.setDouble(10, machine.getCapacityRangeTo() != null ? machine.getCapacityRangeTo() : 0.0);
	                cs.setString(11, machine.getRemark());
	                cs.setString(12, machine.getLocation());
	                cs.setString(13, machine.getPurchaseDate());
	                cs.setDouble(14, machine.getMachineCostPerHour() != null ? machine.getMachineCostPerHour() : 0.0);
	                cs.setDouble(15, machine.getStdProdPerHour() != null ? machine.getStdProdPerHour() : 0.0);
	                cs.setString(16, machine.getMcChar());
	                cs.setInt(17, machine.getMachineTypeId() != null ? machine.getMachineTypeId() : 0);
	                cs.setString(18, machine.getManualCode());
	                cs.setString(19, machine.getManualName());
	                cs.setString(20, machine.getInternalCode());
	                cs.setString(21, machine.getMachineObsolete());
	                cs.setDouble(22, machine.getMachinePowerKw() != null ? machine.getMachinePowerKw() : 0.0);
	                cs.setLong(23, machine.getMachinePurchasePrice() != null ? machine.getMachinePurchasePrice() : 0L);
	                cs.registerOutParameter(24, Types.BIGINT); 
	                return cs;
	            },
	            (CallableStatementCallback<Long>) cs -> {
	                cs.execute();
	                return cs.getLong(24); 
	            }
	        );
	    }

	    
	    public List<Machine> getAllMachines() {
	        return jdbcTemplate.execute((ConnectionCallback<List<Machine>>) con -> {
	            try (var cs = con.prepareCall("{CALL get_all_machines()}")) {
	                List<Machine> list = new ArrayList<>();
	                try (ResultSet rs = cs.executeQuery()) {
	                    while (rs.next()) {
	                        Machine machine = new Machine();
	                        machine.setSrNo(rs.getInt("sr_no"));
	                        machine.setCmpCode(rs.getString("cmp_code"));
	                        machine.setGrp(rs.getString("grp"));
	                        machine.setCategoryCode(rs.getString("category_code"));
	                        machine.setMachineNo(rs.getString("machine_no"));
	                        machine.setMachineName(rs.getString("machine_name"));
	                        machine.setMake(rs.getString("make"));
	                        machine.setModel(rs.getString("model"));
	                        machine.setPmPlan(rs.getString("pm_plan"));
	                        machine.setCapacityRangeFrom(rs.getDouble("capacity_range_from"));
	                        machine.setCapacityRangeTo(rs.getDouble("capacity_range_to"));
	                        machine.setRemark(rs.getString("remark"));
	                        machine.setLocation(rs.getString("location"));
	                        machine.setPurchaseDate(rs.getString("purchase_date"));
	                        machine.setMachineCostPerHour(rs.getDouble("machine_cost_per_hour"));
	                        machine.setStdProdPerHour(rs.getDouble("STD_prod_per_hour"));
	                        machine.setMcChar(rs.getString("MC_char"));
	                        machine.setMachineTypeId(rs.getInt("Machine_Type_id"));
	                        machine.setManualCode(rs.getString("manual_code"));
	                        machine.setManualName(rs.getString("manual_name"));
	                        machine.setInternalCode(rs.getString("Internal_code"));
	                        machine.setMachineObsolete(rs.getString("machine_obsolete"));
	                        machine.setMachinePowerKw(rs.getDouble("machine_power_kw"));
	                        machine.setMachinePurchasePrice(rs.getLong("machine_purchase_price"));
	                        list.add(machine);
	                    }
	                }
	                return list;
	            }
	        });
	    }

	     
	    public Machine getMachineById(Integer id) {
	        return jdbcTemplate.execute((ConnectionCallback<Machine>) con -> {
	            try (var cs = con.prepareCall("{CALL get_machine_by_id(?)}")) {
	                cs.setInt(1, id);
	                try (ResultSet rs = cs.executeQuery()) {
	                    if (rs.next()) {
	                        Machine machine = new Machine();
	                        machine.setSrNo(rs.getInt("sr_no"));
	                        machine.setCmpCode(rs.getString("cmp_code"));
	                        machine.setGrp(rs.getString("grp"));
	                        machine.setCategoryCode(rs.getString("category_code"));
	                        machine.setMachineNo(rs.getString("machine_no"));
	                        machine.setMachineName(rs.getString("machine_name"));
	                        machine.setMake(rs.getString("make"));
	                        machine.setModel(rs.getString("model"));
	                        machine.setPmPlan(rs.getString("pm_plan"));
	                        machine.setCapacityRangeFrom(rs.getDouble("capacity_range_from"));
	                        machine.setCapacityRangeTo(rs.getDouble("capacity_range_to"));
	                        machine.setRemark(rs.getString("remark"));
	                        machine.setLocation(rs.getString("location"));
	                        machine.setPurchaseDate(rs.getString("purchase_date"));
	                        machine.setMachineCostPerHour(rs.getDouble("machine_cost_per_hour"));
	                        machine.setStdProdPerHour(rs.getDouble("STD_prod_per_hour"));
	                        machine.setMcChar(rs.getString("MC_char"));
	                        machine.setMachineTypeId(rs.getInt("Machine_Type_id"));
	                        machine.setManualCode(rs.getString("manual_code"));
	                        machine.setManualName(rs.getString("manual_name"));
	                        machine.setInternalCode(rs.getString("Internal_code"));
	                        machine.setMachineObsolete(rs.getString("machine_obsolete"));
	                        machine.setMachinePowerKw(rs.getDouble("machine_power_kw"));
	                        machine.setMachinePurchasePrice(rs.getLong("machine_purchase_price"));
	                        return machine;
	                    }
	                }
	            }
	            return null;
	        });
	    }

	    
	    public boolean updateMachine(Machine machine) {
	        String sql = "{CALL update_machine(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

	        int rowsAffected = jdbcTemplate.update(connection -> {
	            var cs = connection.prepareCall(sql);
	            cs.setInt(1, machine.getSrNo());
	            cs.setString(2, machine.getCmpCode());
	            cs.setString(3, machine.getGrp());
	            cs.setString(4, machine.getCategoryCode());
	            cs.setString(5, machine.getMachineNo());
	            cs.setString(6, machine.getMachineName());
	            cs.setString(7, machine.getMake());
	            cs.setString(8, machine.getModel());
	            cs.setString(9, machine.getPmPlan());
	            cs.setDouble(10, machine.getCapacityRangeFrom() != null ? machine.getCapacityRangeFrom() : 0.0);
	            cs.setDouble(11, machine.getCapacityRangeTo() != null ? machine.getCapacityRangeTo() : 0.0);
	            cs.setString(12, machine.getRemark());
	            cs.setString(13, machine.getLocation());
	            cs.setString(14, machine.getPurchaseDate());
	            cs.setDouble(15, machine.getMachineCostPerHour() != null ? machine.getMachineCostPerHour() : 0.0);
	            cs.setDouble(16, machine.getStdProdPerHour() != null ? machine.getStdProdPerHour() : 0.0);
	            cs.setString(17, machine.getMcChar());
	            cs.setInt(18, machine.getMachineTypeId() != null ? machine.getMachineTypeId() : 0);
	            cs.setString(19, machine.getManualCode());
	            cs.setString(20, machine.getManualName());
	            cs.setString(21, machine.getInternalCode());
	            cs.setString(22, machine.getMachineObsolete());
	            cs.setDouble(23, machine.getMachinePowerKw() != null ? machine.getMachinePowerKw() : 0.0);
	            cs.setLong(24, machine.getMachinePurchasePrice() != null ? machine.getMachinePurchasePrice() : 0L);
	            return cs;
	        });

	        System.out.println("Rows affected: " + rowsAffected);
	        return rowsAffected > 0;
	    }
 
	    public boolean deleteMachine(Integer id) {
	        String sql = "{CALL delete_machine(?)}";

	        int rowsAffected = jdbcTemplate.update(connection -> {
	            var cs = connection.prepareCall(sql);
	            cs.setInt(1, id);
	            return cs;
	        });

	        return rowsAffected > 0;
	    }
}
