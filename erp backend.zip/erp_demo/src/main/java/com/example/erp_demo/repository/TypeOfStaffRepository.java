package com.example.erp_demo.repository;

import com.example.erp_demo.entity.TypeOfStaffMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TypeOfStaffRepository extends JpaRepository<TypeOfStaffMaster, Integer> {
}

