package com.example.erp_demo.repository;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.erp_demo.entity.Employee;

@Repository
public class EmployeeRepo {

	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	
	public String generateNextEmpCode() {
		return jdbcTemplate.execute((CallableStatementCreator) connection -> {
			CallableStatement cs = connection.prepareCall("{CALL master_employee_master_generateNextEmpCode(?)}");
			cs.registerOutParameter(1, Types.VARCHAR);
			return cs;
		}, (CallableStatementCallback<String>) cs -> {
			cs.execute();
			return cs.getString(1);
		});
	}
	
	public int create(Employee emp) {
        return jdbcTemplate.execute(
            (CallableStatementCreator) connection -> {
                CallableStatement cs = connection.prepareCall("{CALL master_employee_master_save(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

                cs.setString(1, emp.getEmpCode());
                cs.setString(2, emp.getTitle());
                cs.setString(3, emp.getFirstName());
                cs.setString(4, emp.getMiddleName());
                cs.setString(5, emp.getLastName());
                cs.setString(6, emp.getContactNo());
                cs.setString(7, emp.getMobileNo());
                cs.setString(8, emp.getEmailId());
                cs.setString(9, emp.getDateOfBirth()); 
                cs.setObject(10, emp.getgId(), Types.INTEGER);
                cs.setObject(11, emp.getBloodGroupId(), Types.INTEGER);
                cs.setObject(12, emp.getMsId(), Types.INTEGER);
                cs.setObject(13, emp.getCtc(), Types.INTEGER);
                cs.setObject(14, emp.getGrossAmount(), Types.INTEGER);
                cs.setString(15, emp.getTempAddress());
                cs.setString(16, emp.getDocument_name());
                cs.setString(17, emp.getTraining_details());
                cs.setString(18, emp.getPanNo());
                cs.setString(19, emp.getEsicAccNo());
                cs.setString(20, emp.getAuto_mail());
                cs.setObject(21, emp.getLeave_id(), Types.INTEGER);
                cs.setObject(22, emp.getAttendance_id(), Types.INTEGER);
                cs.setString(23, emp.getEmp_photo());
                cs.setString(24, emp.getDate_of_join());
                cs.setObject(25, emp.getQualificationId(), Types.INTEGER);
                cs.setObject(26, emp.getDesignationId(), Types.INTEGER);
                cs.setObject(27, emp.getDid(), Types.INTEGER);
                cs.setObject(28, emp.getCategory_id(), Types.INTEGER);
                cs.setObject(29, emp.getWid(), Types.INTEGER);
                cs.setObject(30, emp.getContractorId(), Types.INTEGER);
                cs.setObject(31, emp.getStaff_id(), Types.INTEGER);
                cs.setObject(32, emp.getPayTypeId(), Types.INTEGER);
                cs.setObject(33, emp.getUnitId(), Types.INTEGER);
                cs.setObject(34, emp.getAadharNo(), Types.INTEGER); 
                cs.setObject(35, emp.getBalance(), Types.INTEGER);
                cs.setString(36, emp.getPermanentAddress());
                cs.setString(37, emp.getAsset());
                cs.setString(38, emp.getApprasal_history());
                cs.setString(39, emp.getPfacc_no());
                cs.setString(40, emp.getIsLeft());
                cs.setString(41, emp.getLeftDate());
                cs.setObject(42, emp.getCityId(), Types.INTEGER);
                cs.setObject(43, emp.getStateId(), Types.INTEGER);
                cs.setObject(44, emp.getCountryId(), Types.INTEGER);
                cs.setString(45, emp.getCid());

                 
                return cs;
    		}, (CallableStatementCallback<Integer>) cs -> {
    			cs.execute();
    			return 1;
    		});
    	}

    
    public List<Employee> getAllEmployees() {
        return jdbcTemplate.execute((ConnectionCallback<List<Employee>>) con -> {
            try (var cs = con.prepareCall("{CALL master_employee_master_getAll()}")) {
                List<Employee> list = new ArrayList<>();
                try (ResultSet rs = cs.executeQuery()) {
                    while (rs.next()) {
                        Employee emp = new Employee();
                        emp.setESrNo(rs.getInt("e_sr_no"));
                        emp.setEmpCode(rs.getString("emp_code"));
                        emp.setTitle(rs.getString("title"));
                        emp.setFirstName(rs.getString("first_name"));
                        emp.setMiddleName(rs.getString("middle_name"));
                        emp.setLastName(rs.getString("last_name"));
                        emp.setContactNo(rs.getString("contact_no"));
                        emp.setMobileNo(rs.getString("mobile_no"));
                        emp.setEmailId(rs.getString("email_id"));
                        emp.setDob(rs.getString("dob"));
                        emp.setgId(rs.getInt("gid"));
                        emp.setBloodGroupId(rs.getInt("blood_group_id"));
                        emp.setMsId(rs.getInt("msid"));
                        emp.setCtc(rs.getInt("ctc"));
                        emp.setGrossAmount(rs.getInt("gross_amount"));
                        emp.setTempAddress(rs.getString("temp_address"));
                        emp.setDocument_name(rs.getString("document_name"));
                        emp.setTraining_details(rs.getString("training_details"));
                        emp.setPanNo(rs.getString("pan_no"));
                        emp.setEsicAccNo(rs.getString("esic_acc_no"));
                        emp.setAuto_mail(rs.getString("auto_mail"));
                        emp.setLeave_id(rs.getInt("leave_id"));
                        emp.setAttendance_id(rs.getInt("attendance_id"));
                        emp.setEmp_photo(rs.getString("emp_photo"));
                        emp.setDate_of_join(rs.getString("date_of_join"));
                        emp.setQualificationId(rs.getInt("qualification_id"));
                        emp.setDesignationId(rs.getInt("designation_id"));
                        emp.setDid(rs.getInt("did"));
                        emp.setCategory_id(rs.getInt("category_id"));
                        emp.setWid(rs.getInt("wid"));
                        emp.setContractorId(rs.getInt("contractor_id"));
                        emp.setStaff_id(rs.getInt("staff_id"));
                        emp.setPayTypeId(rs.getInt("pay_type_id"));
                        emp.setUnitId(rs.getInt("unit_id"));
                        emp.setAadharNo(rs.getInt("aadhar_no"));
                        emp.setBalance(rs.getInt("balance"));
                        emp.setPermanentAddress(rs.getString("permanent_address"));
                        emp.setAsset(rs.getString("asset"));
                        emp.setApprasal_history(rs.getString("apprasal_history"));
                        emp.setPfacc_no(rs.getString("pfacc_no"));
                        emp.setIsLeft(rs.getString("is_left"));
                        emp.setLeftDate(rs.getString("left_date"));
                        emp.setCityId(rs.getInt("city_id"));
                        emp.setStateId(rs.getInt("state_id"));
                        emp.setCountryId(rs.getInt("country_id"));
                        emp.setCid(rs.getString("cid"));
                        emp.setGender(rs.getString("gender"));
                        emp.setCountry_name(rs.getString("country_name"));
                        emp.setState_name(rs.getString("state_name"));
                        emp.setCity_name(rs.getString("city_name"));
                        emp.setBloodGroup(rs.getString("blood_group"));
                        emp.setMarital_status(rs.getString("marital_status"));
                        emp.setLeave_name(rs.getString("leave_name"));
                        emp.setQualification_name(rs.getString("qualification_name"));
                        emp.setDesignation_name(rs.getString("designation_name"));
                        emp.setContractor_name(rs.getString("contractor_name"));
                        emp.setType_of_staff(rs.getString("type_of_staff"));
                        emp.setPay_type_name(rs.getString("pay_type_name"));
                        emp.setCompany_name(rs.getString("company_name"));
                        emp.setWeek_off(rs.getString("week_off"));
                        emp.setD_name(rs.getString("d_name"));
                        emp.setUnit_name(rs.getString("unit_name"));
                        emp.setCategory_name(rs.getString("category_name"));
                         
                        list.add(emp);
                    }
                }
                return list;
            }
        });
    }

//	public List<Employee> getAllEmployees() {
//
//	    return jdbcTemplate.execute((ConnectionCallback<List<Employee>>) con -> {
//
//	        try (var cs = con.prepareCall("{CALL master_employee_master_getAll()}")) {
//
//	            Map<Integer, Employee> empMap = new LinkedHashMap<>();
//
//	            try (ResultSet rs = cs.executeQuery()) {
//
//	                while (rs.next()) {
//
//	                    Integer empId = rs.getInt("e_sr_no");
//
//	                    Employee emp = empMap.get(empId);
//
//	                    if (emp == null) {
//	                        emp = new Employee();
//
//	                        emp.setId(empId);
//	                        emp.setEmpCode(rs.getString("emp_code"));
//	                        emp.setTitle(rs.getString("title"));
//	                        emp.setFirstName(rs.getString("first_name"));
//	                        emp.setMiddleName(rs.getString("middle_name"));
//	                        emp.setLastName(rs.getString("last_name"));
//	                        emp.setContactNo(rs.getString("contact_no"));
//	                        emp.setMobileNo(rs.getString("mobile_no"));
//	                        emp.setEmailId(rs.getString("email_id"));
//	                        emp.setDob(rs.getString("dob"));
//
//	                        emp.setgId(rs.getObject("gid", Integer.class));
//	                        emp.setBloodGroupId(rs.getObject("blood_group_id", Integer.class));
//	                        emp.setMsId(rs.getObject("msid", Integer.class));
//	                        emp.setCtc(rs.getObject("ctc", Integer.class));
//	                        emp.setGrossAmount(rs.getObject("gross_amount", Integer.class));
//	                        emp.setBalance(rs.getObject("balance", Integer.class));
//
//	                        emp.setTemporaryAddress(rs.getString("temp_address"));
//	                        emp.setPermanentAddress(rs.getString("permanent_address"));
//
//	                        emp.setPanNo(rs.getString("pan_no"));
//	                        emp.setAadharNo(rs.getInt("aadhar_no"));
//	                        emp.setPfAccountNo(rs.getString("pfacc_no"));
//	                        emp.setEsicAccountNo(rs.getString("esic_acc_no"));
//
//	                        emp.setIsLeft(rs.getString("is_left"));
//	                        emp.setLeftDate(rs.getString("left_date"));
//
//	                        emp.setCityId(rs.getObject("city_id", Integer.class));
//	                        emp.setStateId(rs.getObject("state_id", Integer.class));
//	                        emp.setCountryId(rs.getObject("country_id", Integer.class));
//
//	                        emp.setCid(rs.getString("cid"));
//
//	                        // ---------- TRANSIENT FIELDS ----------
//	                        emp.setGender(rs.getString("gender"));
//	                        emp.setCountryName(rs.getString("country_name"));
//	                        emp.setStateName(rs.getString("state_name"));
//	                        emp.setCityName(rs.getString("city_name"));
//	                        emp.setBloodGroup(rs.getString("blood_group"));
//	                        emp.setMaritalStatus(rs.getString("marital_status"));
//	                        emp.setLeaveName(rs.getString("leave_name"));
//	                        emp.setQualificationName(rs.getString("qualification_name"));
//	                        emp.setDesignation_name(rs.getString("designation_name"));
//	                        emp.setContractor_name(rs.getString("contractor_name"));
//	                        emp.setType_of_staff(rs.getString("type_of_staff"));
//	                        emp.setPay_type_name(rs.getString("pay_type_name"));
//	                        emp.setCompany_name(rs.getString("company_name"));
//	                        emp.setWeek_off(rs.getString("week_off"));
//	                        emp.setD_name(rs.getString("d_name"));
//
//	                        empMap.put(empId, emp);
//	                    }
//	                }
//	            }
//
//	            return new ArrayList<>(empMap.values());
//	        }
//	    });
//	}

    
    public Employee getEmployeeById(int id) {
        return jdbcTemplate.execute((ConnectionCallback<Employee>) con -> {
            try (var cs = con.prepareCall("{CALL master_employee_master_getById(?)}")) {
                cs.setLong(1, id);
                try (ResultSet rs = cs.executeQuery()) {
                    if (rs.next()) {
                        Employee emp = new Employee();
                        emp.setESrNo(rs.getInt("e_sr_no"));
                        emp.setEmpCode(rs.getString("emp_code"));
                        emp.setTitle(rs.getString("title"));
                        emp.setFirstName(rs.getString("first_name"));
                        emp.setMiddleName(rs.getString("middle_name"));
                        emp.setLastName(rs.getString("last_name"));
                        emp.setContactNo(rs.getString("contact_no"));
                        emp.setMobileNo(rs.getString("mobile_no"));
                        emp.setEmailId(rs.getString("email_id"));
                        emp.setDob(rs.getString("dob"));
                        emp.setgId(rs.getInt("gid"));
                        emp.setBloodGroupId(rs.getInt("blood_group_id"));
                        emp.setMsId(rs.getInt("msid"));
                        emp.setCtc(rs.getInt("ctc"));
                        emp.setGrossAmount(rs.getInt("gross_amount"));
                        emp.setTempAddress(rs.getString("temp_address"));
                        emp.setDocument_name(rs.getString("document_name"));
                        emp.setTraining_details(rs.getString("training_details"));
                        emp.setPanNo(rs.getString("pan_no"));
                        emp.setEsicAccNo(rs.getString("esic_acc_no"));
                        emp.setAuto_mail(rs.getString("auto_mail"));
                        emp.setLeave_id(rs.getInt("leave_id"));
                        emp.setAttendance_id(rs.getInt("attendance_id"));
                        emp.setEmp_photo(rs.getString("emp_photo"));
                        emp.setDate_of_join(rs.getString("date_of_join"));
                        emp.setQualificationId(rs.getInt("qualification_id"));
                        emp.setDesignationId(rs.getInt("designation_id"));
                        emp.setDid(rs.getInt("did"));
                        emp.setCategory_id(rs.getInt("category_id"));
                        emp.setWid(rs.getInt("wid"));
                        emp.setContractorId(rs.getInt("contractor_id"));
                        emp.setStaff_id(rs.getInt("staff_id"));
                        emp.setPayTypeId(rs.getInt("pay_type_id"));
                        emp.setUnitId(rs.getInt("unit_id"));
                        emp.setAadharNo(rs.getInt("aadhar_no"));
                        emp.setBalance(rs.getInt("balance"));
                        emp.setPermanentAddress(rs.getString("permanent_address"));
                        emp.setAsset(rs.getString("asset"));
                        emp.setApprasal_history(rs.getString("apprasal_history"));
                        emp.setPfacc_no(rs.getString("pfacc_no"));
                        emp.setIsLeft(rs.getString("is_left"));
                        emp.setLeftDate(rs.getString("left_date"));
                        emp.setCityId(rs.getInt("city_id"));
                        emp.setStateId(rs.getInt("state_id"));
                        emp.setCountryId(rs.getInt("country_id"));
                        emp.setCid(rs.getString("cid"));
                        emp.setBloodGroup(rs.getString("blood_group"));
                        return emp;
                    }
                }
            }
            return null;
        });
    }


     
    public boolean updateEmployee(Employee emp) {
        String sql = "{CALL master_employee_master_update(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";

        int rowsAffected = jdbcTemplate.update(connection -> {
            var cs = connection.prepareCall(sql);
            cs.setInt(1, emp.getESrNo());
            cs.setString(2, emp.getEmpCode());
            cs.setString(3, emp.getTitle());
            cs.setString(4, emp.getFirstName());
            cs.setString(5, emp.getMiddleName());
            cs.setString(6, emp.getLastName());
            cs.setString(7, emp.getContactNo());
            cs.setString(8, emp.getMobileNo());
            cs.setString(9, emp.getEmailId());
            cs.setString(10, emp.getDateOfBirth());
            cs.setInt(11, emp.getgId());
            cs.setInt(12, emp.getBloodGroupId());
            cs.setInt(13, emp.getMsId());
            cs.setInt(14, emp.getCtc());
            cs.setInt(15, emp.getGrossAmount());
            cs.setString(16, emp.getTempAddress());
            cs.setString(17, emp.getDocument_name());
            cs.setString(18, emp.getTraining_details());
            cs.setString(19, emp.getPanNo());
            cs.setString(20, emp.getEsicAccNo());
            cs.setString(21, emp.getAuto_mail());
            cs.setInt(22, emp.getLeave_id());
            cs.setInt(23, emp.getAttendance_id());
            cs.setString(24, emp.getEmp_photo());
            cs.setString(25, emp.getDate_of_join());
            cs.setInt(26, emp.getQualificationId());
            cs.setInt(27, emp.getDesignationId());
            cs.setInt(28, emp.getDid());
            cs.setInt(29, emp.getCategory_id());
            cs.setInt(30, emp.getWid());
            cs.setInt(31, emp.getContractorId());
            cs.setInt(32, emp.getStaff_id());
            cs.setInt(33, emp.getPayTypeId());
            cs.setInt(34, emp.getUnitId());
            cs.setLong(35, emp.getAadharNo());
            cs.setInt(36, emp.getBalance());
            cs.setString(37, emp.getPermanentAddress());
            cs.setString(38, emp.getAsset());
            cs.setString(39, emp.getApprasal_history());
            cs.setString(40, emp.getPfacc_no());
            cs.setString(41, emp.getIsLeft());
            cs.setString(42, emp.getLeftDate());
            cs.setInt(43, emp.getCityId());
            cs.setInt(44, emp.getStateId());
            cs.setInt(45, emp.getCountryId());
            cs.setString(46, emp.getCid());
            return cs;
        });

        return rowsAffected > 0;
    }

    
    public boolean deleteEmployee(int id) {
        String sql = "{CALL master_employee_master_deleteById(?)}";

        int rowsAffected = jdbcTemplate.update(connection -> {
            var cs = connection.prepareCall(sql);
            cs.setLong(1, id);
            return cs;
        });

        return rowsAffected > 0;
    }
}
