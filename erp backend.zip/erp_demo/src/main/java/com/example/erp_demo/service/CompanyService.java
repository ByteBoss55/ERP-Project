package com.example.erp_demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Company;
import com.example.erp_demo.repository.CompanyRepo;

@Service
public class CompanyService {
	
	@Autowired
    private CompanyRepo repo;
	
	public Company create(Company company) {
        Long id = repo.create(company);
        company.setId(id.intValue());
        return company;
    }

    
    public List<Company> getAllCompanies() {
        return repo.getAllCompanies();
    }

    
    public Company getCompanyById(Integer id) {
        return repo.getCompanyById(id);
    }

    
    public boolean updateCompany(Company company) {
        return repo.updateCompany(company);
    }

   
    public boolean deleteCompany(Integer id) {
        return repo.deleteCompany(id);
    }
}
