package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "supplier_type_master")
public class SupplierTypeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer supp_type_id;

    @Column(name = "supp_type", length = 50)
    private String supp_type;

    public Integer getSuppTypeId() {
        return supp_type_id;
    }

    public void setSuppTypeId(Integer suppTypeId) {
        this.supp_type_id = suppTypeId;
    }

    public String getSuppType() {
        return supp_type;
    }

    public void setSuppType(String supp_type) {
        this.supp_type = supp_type;
    }
}
