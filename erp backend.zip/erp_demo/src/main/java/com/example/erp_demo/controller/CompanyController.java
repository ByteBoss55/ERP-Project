package com.example.erp_demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.entity.Company;
import com.example.erp_demo.service.CompanyService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class CompanyController {

	 

	    @Autowired
	    private CompanyService service;

	     
	    @PostMapping("/savecompany")
	    public ResponseEntity<Company> create(@RequestBody Company company) {
	        return ResponseEntity.ok(service.create(company));
	    }

	    
	    @GetMapping("/getAllCompanies")
	    public List<Company> getAllCompanies() {
	        return service.getAllCompanies();
	    }

	     
	    @GetMapping("/getCompanyById/{id}")
	    public ResponseEntity<?> getCompanyById(@PathVariable Integer id) {
	        Company company = service.getCompanyById(id);
	        if (company == null) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .body("Company with ID " + id + " not found.");
	        } else {
	            return ResponseEntity.ok(company);
	        }
	    }

	    
	    @PutMapping("/updatecompany")
	    public ResponseEntity<String> updateCompany(@RequestBody Company company) {
	        boolean updated = service.updateCompany(company);
	        return updated
	                ? ResponseEntity.ok("Company updated successfully.")
	                : ResponseEntity.status(500).body("Failed to update company.");
	    }

	     
	    @DeleteMapping("/deletecompany/{id}")
	    public ResponseEntity<String> deleteCompany(@PathVariable Integer id) {
	        boolean deleted = service.deleteCompany(id);
	        return deleted
	                ? ResponseEntity.ok("Company deleted successfully.")
	                : ResponseEntity.status(500).body("Failed to delete company.");
	    }
}
