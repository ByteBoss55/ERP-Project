package com.example.erp_demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Item;
import com.example.erp_demo.entity.Supplier;
import com.example.erp_demo.repository.SupplierRepo;

@Service
public class SupplierService {

	 @Autowired
	    private SupplierRepo repo;

	 
	    public String generateNextSuppCode() {
	    	return repo.generateNextSuppCode();
	    }
	     
	    public Integer create(Supplier supplier) {
	    	String nextCode = repo.generateNextSuppCode();
	        supplier.setSuppCode(nextCode);
	        return repo.create(supplier);
	    }

	    
	    public List<Supplier> getAllSuppliers() {
	        return repo.getAllSuppliers();
	    }

	    
	    public Supplier getSupplierById(Integer id) {
	        return repo.getSupplierById(id);
	    }

	     
	    public boolean updateSupplier(Integer id, Supplier supplier) {
	    	return repo.updateSupplier(supplier);
	    }
	    
	    
	    public boolean deleteSupplier(Integer id) {
	        return repo.deleteSupplier(id);
	    }
}
