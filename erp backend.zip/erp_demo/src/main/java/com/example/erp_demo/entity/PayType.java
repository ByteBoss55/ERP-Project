package com.example.erp_demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "pay_type_master")
public class PayType {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pay_type_id")
    private Integer paytypeId;

    @Column(name = "pay_type_name", length = 100)
    private String payTypeName;

	public Integer getPaytypeId() {
		return paytypeId;
	}

	public void setPaytypeId(Integer paytypeId) {
		this.paytypeId = paytypeId;
	}

	public String getPayTypeName() {
		return payTypeName;
	}

	public void setPayTypeName(String payTypeName) {
		this.payTypeName = payTypeName;
	}

}
