package com.example.erp_demo.entity;

 

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.*;

@Entity
@Table(name = "colour_master")
public class ColourMaster {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "colour_id")
    @JsonProperty("colour_id")
    private Integer colour_id;

    @Column(name = "colour_name", length = 100)
    @JsonProperty("colour_name")
    private String colourName;

    @JsonProperty("colour_id")
    public Integer getColour_id() {
        return colour_id;
    }

  //  @JsonProperty("colour_id")
    public void setColour_id(Integer colour_id) {
        this.colour_id = colour_id;
    }

 //   @JsonProperty("colour_name")
    public String getColourName() {
        return colourName;
    }

  //  @JsonProperty("colour_name")
    public void setColourName(String colourName) {
        this.colourName = colourName;
    }
}