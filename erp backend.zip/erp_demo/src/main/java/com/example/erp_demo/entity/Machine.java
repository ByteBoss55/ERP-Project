package com.example.erp_demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "machine_master")
public class Machine {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sr_no")
    private Integer id;

    @Column(name = "cmp_code", length = 50)
    private String cmpCode;

    @Column(name = "grp", length = 50)
    private String grp;

    @Column(name = "category_code", length = 50)
    private String categoryCode;

    @Column(name = "machine_no", length = 50, unique = true, nullable = false)
    private String machineNo;

    @Column(name = "machine_name", length = 255)
    private String machineName;

    @Column(name = "make", length = 255)
    private String make;

    @Column(name = "model", length = 255)
    private String model;

    @Column(name = "pm_plan", length = 255)
    private String pmPlan;

    @Column(name = "capacity_range_from")
    private Double capacityRangeFrom;

    @Column(name = "capacity_range_to")
    private Double capacityRangeTo;

    @Column(name = "remark", length = 255)
    private String remark;

    @Column(name = "location", length = 255)
    private String location;

    @Column(name = "purchase_date")
    private String purchaseDate;

    @Column(name = "machine_cost_per_hour")
    private Double machineCostPerHour;

    @Column(name = "STD_prod_per_hour")
    private Double stdProdPerHour;

    @Column(name = "MC_char", length = 255)
    private String mcChar;

    @Column(name = "Machine_Type_id")
    private Integer machineTypeId;

    @Column(name = "manual_code", length = 100)
    private String manualCode;

    @Column(name = "manual_name", length = 255)
    private String manualName;

    @Column(name = "Internal_code", length = 100)
    private String internalCode;

    @Column(name = "machine_obsolete", length = 10)
    private String machineObsolete;

    @Column(name = "machine_power_kw")
    private Double machinePowerKw;

    @Column(name = "machine_purchase_price")
    private Long machinePurchasePrice;

    // ✅ Getters and Setters
    public Integer getSrNo() {
        return id;
    }

    public void setSrNo(Integer srNo) {
        this.id = srNo;
    }

    public String getCmpCode() {
        return cmpCode;
    }

    public void setCmpCode(String cmpCode) {
        this.cmpCode = cmpCode;
    }

    public String getGrp() {
        return grp;
    }

    public void setGrp(String grp) {
        this.grp = grp;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getMachineNo() {
        return machineNo;
    }

    public void setMachineNo(String machineNo) {
        this.machineNo = machineNo;
    }

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getPmPlan() {
        return pmPlan;
    }

    public void setPmPlan(String pmPlan) {
        this.pmPlan = pmPlan;
    }

    public Double getCapacityRangeFrom() {
        return capacityRangeFrom;
    }
    
    public void setCapacityRangeFrom(Double capacityRangeFrom) {
        this.capacityRangeFrom = capacityRangeFrom;
    }

    public Double getCapacityRangeTo() {
        return capacityRangeTo;
    }

    public void setCapacityRangeTo(Double capacityRangeTo) {
        this.capacityRangeTo = capacityRangeTo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public Double getMachineCostPerHour() {
        return machineCostPerHour;
    }

    public void setMachineCostPerHour(Double machineCostPerHour) {
        this.machineCostPerHour = machineCostPerHour;
    }

    public Double getStdProdPerHour() {
        return stdProdPerHour;
    }

    public void setStdProdPerHour(Double stdProdPerHour) {
        this.stdProdPerHour = stdProdPerHour;
    }

    public String getMcChar() {
        return mcChar;
    }

    public void setMcChar(String mcChar) {
        this.mcChar = mcChar;
    }

    public Integer getMachineTypeId() {
        return machineTypeId;
    }

    public void setMachineTypeId(Integer machineTypeId) {
        this.machineTypeId = machineTypeId;
    }

    public String getManualCode() {
        return manualCode;
    }

    public void setManualCode(String manualCode) {
        this.manualCode = manualCode;
    }

    public String getManualName() {
        return manualName;
    }

    public void setManualName(String manualName) {
        this.manualName = manualName;
    }

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public String getMachineObsolete() {
        return machineObsolete;
    }

    public void setMachineObsolete(String machineObsolete) {
        this.machineObsolete = machineObsolete;
    }

    public Double getMachinePowerKw() {
        return machinePowerKw;
    }

    public void setMachinePowerKw(Double machinePowerKw) {
        this.machinePowerKw = machinePowerKw;
    }

    public Long getMachinePurchasePrice() {
        return machinePurchasePrice;
    }

    public void setMachinePurchasePrice(Long machinePurchasePrice) {
        this.machinePurchasePrice = machinePurchasePrice;
    }
}
