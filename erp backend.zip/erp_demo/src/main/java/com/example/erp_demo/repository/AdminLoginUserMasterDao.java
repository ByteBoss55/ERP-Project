package com.example.erp_demo.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;

@Repository
public class AdminLoginUserMasterDao {
	
	@Autowired
	SessionFactory factory;

	public Map<String, Object> authenticateAdminUser1(String username, String password) {
	    Map<String, Object> resultMap = new HashMap<>();
	    Session session = null;
	    Transaction transaction = null;

	    try {
	        session = factory.openSession();
	        transaction = session.beginTransaction();

	        // Create the stored procedure query
	        StoredProcedureQuery query = session.createStoredProcedureQuery("admin_login_user_authentication")
	                                            .registerStoredProcedureParameter(1, String.class, ParameterMode.IN)
	                                            .registerStoredProcedureParameter(2, String.class, ParameterMode.IN)
	                                            .setParameter(1, username)
	                                            .setParameter(2, password);

	        // Execute the query and get the result list
	        List<Object[]> resultList = query.getResultList();
	        if (!resultList.isEmpty()) {
	            Object[] result = resultList.get(0);

	            // Check if result[0] is not null to ensure data is present
	            if (result[0] != null) {
	                resultMap.put("login_user_id", result[0]);
	                resultMap.put("user_name", result[1]);
	                resultMap.put("password", result[2]);
	                resultMap.put("is_active", result[3]);
	                resultMap.put("roleid", result[4]);
	                resultMap.put("employee_id", result[5]);
	                resultMap.put("branch_id", result[6]);
	                resultMap.put("system_entry_date", result[7]);
	                resultMap.put("is_loggedin", result[8]);
	                resultMap.put("branch_name", result[9]);

	                // Update the is_loggedin status to true
	                String updateQuery = "UPDATE AdminLoginUserMaster SET is_loggedin = true WHERE login_user_id = :loginUserId";
	                session.createQuery(updateQuery)
	                       .setParameter("loginUserId", result[0]) 
	                       .executeUpdate();

	             
	                transaction.commit();
	            } else {
	                System.err.println("Stored procedure returned null for result[0]");
	            }
	        } else {
	            // If resultList is empty, no matching user found
	            transaction.rollback();
	            System.err.println("No user found for the given username and password");
	        }
	    } catch (Exception e) {
	        if (transaction != null) {
	            transaction.rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        if (session != null) {
	            session.close();
	        }
	    }

	    return resultMap;
	}
	
	public void logoutAdminUser(int loginUserId) {
	    Session session = null;
	    Transaction transaction = null;

	    try {
	        session = factory.openSession();
	        transaction = session.beginTransaction();

	        // Update the is_loggedin status to false
	        String updateQuery = "UPDATE AdminLoginUserMaster SET is_loggedin = false WHERE login_user_id = :loginUserId";
	        session.createQuery(updateQuery)
	               .setParameter("loginUserId", loginUserId) 
	               .executeUpdate();

	        // Commit the transaction after updating the is_loggedin status
	        transaction.commit();
	    } catch (Exception e) {
	        if (transaction != null) {
	            transaction.rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        if (session != null) {
	            session.close();
	        }
	    }
	}
}
