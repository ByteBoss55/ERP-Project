package com.example.erp_demo.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "manufacturer_master")
public class ManufacturerMaster {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "manufacturer_id")
	    @JsonProperty("manufacturer_id")
	    private Integer manufacturer_id;

	    @Column(name = "manufacturer_name", length = 255)
	    @JsonProperty("manufacturer_name")
	    private String manufacturerName;

	    // FIXED GETTER/SETTER
	//    @JsonProperty("manufacturer_id")
	    public Integer getManufacturer_id() {
	        return manufacturer_id;
	    }

//	    @JsonProperty("manufacturer_id")
	    public void setManufacturer_id(Integer manufacturer_id) {
	        this.manufacturer_id = manufacturer_id;
	    }

	    @JsonProperty("manufacturer_name")
	    public String getManufacturerName() {
	        return manufacturerName;
	    }

	    @JsonProperty("manufacturer_name")
	    public void setManufacturerName(String manufacturerName) {
	        this.manufacturerName = manufacturerName;
	    }
}
