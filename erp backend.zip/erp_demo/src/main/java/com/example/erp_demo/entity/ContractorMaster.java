package com.example.erp_demo.entity;

 

import jakarta.persistence.*;

@Entity
@Table(name = "contractor_master")
public class ContractorMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "contractor_id")
    private Integer contractorId;

    @Column(name = "contractor_name", length = 100)
    private String contractorName;

    public Integer getContractorId() {
        return contractorId;
    }

    public void setContractorId(Integer contractorId) {
        this.contractorId = contractorId;
    }

    public String getContractorName() {
        return contractorName;
    }

    public void setContractorName(String contractorName) {
        this.contractorName = contractorName;
    }
}

