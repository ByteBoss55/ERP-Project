package com.example.erp_demo.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.entity.Country;
import com.example.erp_demo.entity.Customer;
import com.example.erp_demo.entity.Item;
import com.example.erp_demo.projection.CustomerMasterProjection;
import com.example.erp_demo.projection.ItemMasterProjection;
import com.example.erp_demo.service.CustomerService;
import com.example.erp_demo.service.CustomerServiceJPA;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class CustomerController {

	@Autowired
	private CustomerService service;

	@PostMapping("savecustomer")
	public ResponseEntity<Customer> create(@RequestBody Customer cust) {
		return ResponseEntity.ok(service.create(cust));
	}

	@GetMapping("getAllCustomers")
	public List<Customer> getAllCustomers() {
		return service.getAllCustomers();
	}

	@GetMapping("getCustomerbyid/{id}")
	public ResponseEntity<?> getCustomer(@PathVariable Long id) {
		Customer cust = service.getCustomerById(id);
		if (cust == null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer with ID " + id + " not found.");
		} else {
			return ResponseEntity.ok(cust);
		}
	}

	@PutMapping("/updatecustomer/{id}")
	public ResponseEntity<String> updateCustomer(@PathVariable int id, @RequestBody Customer cust) {

		cust.setId(id); // ensure the ID in path is used and not body ID

		boolean updated = service.updateCustomer(cust);

		return updated ? ResponseEntity.ok("Customer updated successfully.")
				: ResponseEntity.status(404).body("Customer not found.");
	}

	@DeleteMapping("/deletecustomer/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {
		boolean deleted = service.deleteCustomer(id);
		return deleted ? ResponseEntity.ok("Customer deleted successfully.")
				: ResponseEntity.status(500).body("Failed to delete customer.");
	}

	@GetMapping("nextcustomercode")
	public ResponseEntity<String> getNextItemCode() {
		String nextCode = service.generateNextCustomerCode();
		return ResponseEntity.ok(nextCode);
	}

	@GetMapping("/searchCustomerMaster/{searchTerm}")
	public ResponseEntity<List<Customer>> search(@PathVariable String searchTerm) {
		return ResponseEntity.ok(service.search(searchTerm));
	}

//----------------------------------------------------------------------------------------------------------------------------------------------

	// dropdown Country -> State -> City
	@GetMapping("/allCountries")
	public List<Map<String, Object>> getAllCountries() {
		return service.getAllCountries();
	}

	@GetMapping("/getState/{countryId}")
	public List<Map<String, Object>> getAllStates(@PathVariable Integer countryId) {
		return service.getAllStatesByCountryId(countryId);
	}

	@GetMapping("/getCity/{stateId}")
	public List<Map<String, Object>> getAllCities(@PathVariable Integer stateId) {
		return service.getAllCitiesByStateId(stateId);
	}
//----------------------------------------------------------------------------------------------------------------------------------------------

	// ✅ Endpoint to save item (auto-generates custCode using stored procedure)

	@Autowired
	private CustomerServiceJPA customerService;

	@GetMapping("/nextcustomercodebyjpa")
	   public ResponseEntity<String> generateNextCustomerCode() {
	       return ResponseEntity.ok(service.generateNextCustomerCode());
	   }


	@PutMapping("/updatecustomergen/{id}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @RequestBody Customer updatedCustomer) {
		Customer customer = customerService.updateCustomer(id, updatedCustomer);
		if (customer != null) {
			return ResponseEntity.ok(customer);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@PostMapping("/saveCustomerJPA")
    public ResponseEntity<Customer> createCustomerJPA(@RequestBody Customer customer) {
		Customer savedCustomer = customerService.saveCustomer(customer);
        return ResponseEntity.ok(savedCustomer);
    }

    @GetMapping("/getAllCustomersJPA")
    public ResponseEntity<List<CustomerMasterProjection>> getAllCustomersJPA() {
    List<CustomerMasterProjection> customers = customerService.getAllCustomers();
    return ResponseEntity.ok(customers);
    }

    @GetMapping("/getCustomerByIdJPA/{id}")
    public ResponseEntity<?> getCustomerByIdJPA(@PathVariable Long id) {

        Optional<Customer> customer = customerService.getCustomerById(id);

        if (customer.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Customer with ID " + id + " not found.");
        }

        return ResponseEntity.ok(customer.get());
    }

    @PutMapping("/updateCustomerByJPA/{id}")
    public ResponseEntity<?> updateCustomerJPA(@PathVariable Long id){
    	try {
    		customerService.updateCustomer(id, null);
    		return ResponseEntity.ok("Customer with ID " + "updated successfully.");
    	} catch (RuntimeException ex) {
    		return ResponseEntity.status(HttpStatus.NOT_FOUND)
    				.body(ex.getMessage());
    	}
    }
    
    @DeleteMapping("/deleteCustomerJPA/{id}")
    public ResponseEntity<?> deleteCustomerJPA(@PathVariable Long id) {

        try {
        	customerService.deleteCustomer(id);
            return ResponseEntity.ok("Customer with ID " + id + " deleted successfully.");
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ex.getMessage());
        }
    }
}
