package com.example.erp_demo.repository;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.stereotype.Repository;
import com.example.erp_demo.entity.Item;

@Repository
public class ItemRepo {

	@Autowired
	private JdbcTemplate jdbcTemplate;
 

	public String generateNextItemCode() {
		return jdbcTemplate.execute((CallableStatementCreator) connection -> {
			CallableStatement cs = connection.prepareCall("{CALL master_item_master_generateNextItemCode(?)}");
			cs.registerOutParameter(1, Types.VARCHAR);
			return cs;
		}, (CallableStatementCallback<String>) cs -> {
			cs.execute();
			return cs.getString(1);
		});
	}

	public int create(Item item) {
		return jdbcTemplate.execute((CallableStatementCreator) connection -> {
			CallableStatement cs = connection
					.prepareCall("{CALL master_item_master_save(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			cs.setString(1, item.getItemCode());
			cs.setString(2, item.getItemName());
			cs.setString(3, item.getMaterial());
			cs.setString(4, "Raw");
			cs.setString(5, "Rod");
			cs.setString(6, item.getHsn_code());

			// Handle null-safe values
			if (item.getGstRate() == null)
				cs.setNull(7, Types.DECIMAL);
			else
				cs.setDouble(7, item.getGstRate());

			if (item.getPurchaseCost() == null)
				cs.setNull(8, Types.DECIMAL);
			else
				cs.setDouble(8, item.getPurchaseCost());

			if (item.getSellingPrice() == null)
				cs.setNull(9, Types.DECIMAL);
			else
				cs.setDouble(9, item.getSellingPrice());

			cs.setString(10, "admin");
			cs.setString(11, "MAIN-BRANCH");
			cs.setString(12, "2020-06-22 16:29:27");
			cs.setString(13, "Yes");

			// Handle NULL-safe integers
			if (item.getSubCategoryId() == null)
				cs.setNull(14, Types.INTEGER);
			else
				cs.setInt(14, item.getSubCategoryId());

			if (item.getManufacturerId() == null)
				cs.setNull(15, Types.INTEGER);
			else
				cs.setInt(15, item.getManufacturerId());

			if (item.getColourId() == null)
				cs.setNull(16, Types.INTEGER);
			else
				cs.setInt(16, item.getColourId());

			if (item.getUnitId() == null)
				cs.setNull(17, Types.INTEGER);
			else
				cs.setInt(17, item.getUnitId());

			if (item.getBranchId() == null)
				cs.setNull(18, Types.INTEGER);
			else
				cs.setInt(18, 1);

			if (item.getCategoryId() == null)
				cs.setNull(19, Types.INTEGER);
			else
				cs.setInt(19, item.getCategoryId());

			cs.setString(20, "DRW001");
			cs.setString(21, "item specification 10");

			return cs;
		}, (CallableStatementCallback<Integer>) cs -> {
			cs.execute();
			return 1;
		});
	}

	public List<Item> getAllItems() {
		return jdbcTemplate.execute((ConnectionCallback<List<Item>>) con -> {
			try (var cs = con.prepareCall("{CALL master_item_master_getAll()}")) {
				List<Item> list = new ArrayList<>();
				try (ResultSet rs = cs.executeQuery()) {
					while (rs.next()) {
						Item item = new Item();

						item.setId((Integer) rs.getInt("id"));
						item.setItemCode(rs.getString("item_code"));
						item.setItemName(rs.getString("item_name"));
						item.setMaterial(rs.getString("material"));
						item.setItemType(rs.getString("item_type"));
						item.setItemSubType(rs.getString("item_sub_type"));
						item.setHsn_code(rs.getString("hsn_code")); // NEW FIELD

						item.setGstRate(rs.getDouble("gst_rate"));
						item.setPurchaseCost(rs.getDouble("purchase_cost"));
						item.setSellingPrice(rs.getDouble("selling_price"));

						item.setUsername(rs.getString("username"));
						item.setLoginBranch(rs.getString("login_branch"));
						item.setSystemEntryDate(rs.getString("system_entry_date"));

						item.setRawMaterial(rs.getString("raw_material"));
						item.setSubCategoryId(rs.getInt("sub_category_id"));
						item.setManufacturerId(rs.getInt("manufacturer_id"));
						item.setColourId(rs.getInt("colour_id"));
						item.setUnitId(rs.getInt("unit_id"));
						item.setBranchId(rs.getInt("branch_id"));
						item.setCategoryId(rs.getInt("category_id"));

						item.setDrawingNo(rs.getString("drawing_no"));
						item.setSpecification(rs.getString("specification"));

						// New Joined Columns
						item.setColourName(rs.getString("colour_name"));
						item.setUnitName(rs.getString("unit_name"));
						item.setManufacturerName(rs.getString("manufacturer_name"));
						item.setCategoryName(rs.getString("category_name"));
						item.setSubCategoryName(rs.getString("sub_category_name"));
						item.setBranchName(rs.getString("branch_name"));

						list.add(item);
					}
				}
				return list;
			}
		});
	}

	public Item getItemById(Integer id) {
		return jdbcTemplate.execute((ConnectionCallback<Item>) con -> {
			try (CallableStatement cs = con.prepareCall("{CALL master_item_master_getById(?)}")) {
				cs.setInt(1, id);
				try (ResultSet rs = cs.executeQuery()) {
					if (rs.next()) {
						Item item = new Item();
						item.setId(rs.getInt("id"));
						item.setItemCode(rs.getString("item_code"));
						item.setItemName(rs.getString("item_name"));
						item.setMaterial(rs.getString("material"));
						item.setItemType(rs.getString("item_type"));
						item.setItemSubType(rs.getString("item_sub_type"));
						item.setHsn_code(rs.getString("hsn_code"));
						item.setGstRate(rs.getDouble("gst_rate"));
						item.setPurchaseCost(rs.getDouble("purchase_cost"));
						item.setSellingPrice(rs.getDouble("selling_price"));
						item.setUsername(rs.getString("username"));
						item.setLoginBranch(rs.getString("login_branch"));
						item.setSystemEntryDate(rs.getString("system_entry_date"));
						item.setRawMaterial(rs.getString("raw_material"));
						item.setSubCategoryId(rs.getInt("sub_category_id"));
						item.setManufacturerId(rs.getInt("manufacturer_id"));
						item.setColourId(rs.getInt("colour_id"));
						item.setUnitId(rs.getInt("unit_id"));
						item.setBranchId(rs.getInt("branch_id"));
						item.setCategoryId(rs.getInt("category_id"));
						item.setDrawingNo(rs.getString("drawing_no"));
						item.setSpecification(rs.getString("specification"));
						return item;
					}
					return null;
				}
			}
		});
	}

	public boolean updateItem(Item item) {
		String sql = "{CALL master_item_master_update(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
		int rowsAffected = jdbcTemplate.update(connection -> {
			var cs = connection.prepareCall(sql);
			cs.setInt(1, item.getId());
			cs.setInt(2, item.getBranchId());
			cs.setInt(3, item.getCategoryId());
			cs.setInt(4, item.getColourId());
			cs.setString(5, item.getDrawingNo());
			cs.setDouble(6, item.getGstRate());
			cs.setString(7, item.getHsn_code());
			cs.setString(8, item.getItemCode());
			cs.setString(9, item.getItemName());
			cs.setString(10, item.getItemSubType());
			cs.setString(11, item.getItemType());
			cs.setString(12, item.getLoginBranch());
			cs.setInt(13, item.getManufacturerId());
			cs.setString(14, item.getMaterial());
			cs.setDouble(15, item.getPurchaseCost());
			cs.setString(16, item.getRawMaterial());
			cs.setDouble(17, item.getSellingPrice());
			cs.setString(18, item.getSpecification());
			cs.setInt(19, item.getSubCategoryId());
			cs.setString(20, item.getSystemEntryDate());
			cs.setInt(21, item.getUnitId());
			cs.setString(22, item.getUsername());
			return cs;
		});
		return rowsAffected > 0;
	}

	public boolean deleteItem(Integer id) {
		String sql = "{CALL master_item_master_deleteById(?)}";

		int rowsAffected = jdbcTemplate.update(connection -> {
			var cs = connection.prepareCall(sql);
			cs.setLong(1, id);
			return cs;
		});

		return rowsAffected > 0;
	}

//	public List<Map<String, Object>> searchItems(String searchTerm) {
//	    String sql = "CALL search_item_master(?)";
//	    return jdbcTemplate.queryForList(sql, searchTerm);
//	}

	public List<Item> searchItemMaster(String searchTerm) {

        String sql = "CALL search_item_master(?)";
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql, searchTerm);

        List<Item> list = new ArrayList<>();

        for (Map<String, Object> row : rows) {
            Item item = new Item();

            item.setId((Integer) row.get("id"));
            item.setItemCode((String) row.get("item_code"));
            item.setItemName((String) row.get("item_name"));
            item.setMaterial((String) row.get("material"));
            item.setItemType((String) row.get("item_type"));
            item.setItemSubType((String) row.get("item_sub_type"));
            item.setHsn_code((String) row.get("hsn_code"));      
            item.setGstRate(row.get("gst_rate") != null ? ((Number) row.get("gst_rate")).doubleValue() : null);
            item.setPurchaseCost(row.get("purchase_cost") != null ? ((Number) row.get("purchase_cost")).doubleValue() : null);
            item.setSellingPrice(row.get("selling_price") != null ? ((Number) row.get("selling_price")).doubleValue() : null);
            item.setUsername((String) row.get("username"));
            item.setLoginBranch((String) row.get("login_branch"));
            item.setSystemEntryDate(String.valueOf(row.get("system_entry_date")));
            item.setRawMaterial((String) row.get("raw_material"));

            item.setSubCategoryId((Integer) row.get("sub_category_id"));
            item.setManufacturerId((Integer) row.get("manufacturer_id"));
            item.setColourId((Integer) row.get("colour_id"));
            item.setUnitId((Integer) row.get("unit_id"));
            item.setBranchId((Integer) row.get("branch_id"));
            item.setCategoryId((Integer) row.get("category_id"));

            item.setDrawingNo((String) row.get("drawing_no"));
            item.setSpecification((String) row.get("specification"));

            item.setColourName((String) row.get("colour_name"));
            item.setUnitName((String) row.get("unit_name"));
            item.setManufacturerName((String) row.get("manufacturer_name"));
            item.setCategoryName((String) row.get("category_name"));
            item.setSubCategoryName((String) row.get("sub_category_name"));
            item.setBranchName((String) row.get("branch_name"));

            list.add(item);
        }

        return list;
    }
}
