package com.example.erp_demo.service;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Country;
import com.example.erp_demo.entity.Customer;
import com.example.erp_demo.entity.Item;
import com.example.erp_demo.repository.CustomerRepo;

@Service
public class CustomerService {
	@Autowired
    private CustomerRepo repo;
	
	 public Customer create(Customer cust) {
	        Integer id = repo.create(cust);
	        cust.setId(id);
	        return cust;
	    }  
	 
	    public List<Customer> getAllCustomers() {
	        return repo.getAllCustomers();
	    }
	    
	    public Customer getCustomerById(Long id) {
	    	return repo.getCustomerById(id);
	    }
	   
	    public boolean updateCustomer(Customer cust) {
	    	return repo.updateCustomer(cust);
	    }
	    public boolean deleteCustomer(Long id) {
	    	return repo.deleteCustomer(id);
	    }
	    
	    public String generateNextCustomerCode() {
			// TODO Auto-generated method stub
			return repo.generateNextCustomerCode();
		}
	    
	    public List<Map<String, Object>> getAllCountries() {
	        return repo.getAllCountries();
	    }
	    
	    public List<Map<String, Object>> getAllStatesByCountryId(Integer countryId) {

	        List<Map<String, Object>> result = repo.getAllStatesByCountryId(countryId);

	        // Remove country_id from every row
	        for (Map<String, Object> row : result) {
	            row.remove("country_id");
	        }

	        return result;
	    }

	
	    
	    public List<Map<String, Object>> getAllCitiesByStateId(Integer stateId) {

	        List<Map<String, Object>> result = repo.getAllCityByStateId(stateId);

	        // Remove state_id before returning
	        for (Map<String, Object> row : result) {
	            row.remove("state_id");
	        }

	        return result;
	    }
		
	    
	    public List<Customer> search(String term) {
	        return repo.searchCustomerMaster(term);
	    }
		
}
	

