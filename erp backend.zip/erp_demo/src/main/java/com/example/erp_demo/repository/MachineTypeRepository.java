package com.example.erp_demo.repository;

import com.example.erp_demo.entity.MachineTypeMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MachineTypeRepository extends JpaRepository<MachineTypeMaster, Integer> {
}

