package com.example.erp_demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.erp_demo.entity.Supplier;
import com.example.erp_demo.service.SupplierService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class SupplierController {

	@Autowired
	private SupplierService service;

	@GetMapping("nextSuppcode")
	public ResponseEntity<String> generateNextSuppCode(){
		String nextCode = service.generateNextSuppCode();
			return ResponseEntity.ok(nextCode);
	}

	@PostMapping("/saveSupplier")
	public ResponseEntity<Integer> create(@RequestBody Supplier supplier) {
		return ResponseEntity.ok(service.create(supplier));

	}

	@GetMapping("/getAllSuppliers")
	public ResponseEntity<List<Supplier>> getAllSuppliers() {
		List<Supplier> list = service.getAllSuppliers();
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/getSupplierById/{id}")
	public ResponseEntity<Supplier> getSupplierById(@PathVariable Integer id) {
		Supplier supplier = service.getSupplierById(id);
		if (supplier != null) {
			return new ResponseEntity<>(supplier, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/updateSupplier/{id}")
	public ResponseEntity<?> updateSupplier(@PathVariable Integer id, Supplier supplier) {
		supplier.setId(id);
        boolean updated = service.updateSupplier(id, supplier);
		if (updated) {
			return new ResponseEntity<>("Supplier updated successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Supplier update failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@DeleteMapping("/deleteSupplier/{id}")
	public ResponseEntity<String> deleteSupplier(@PathVariable Integer id) {
		boolean deleted = service.deleteSupplier(id);
		if (deleted) {
			return new ResponseEntity<>("Supplier deleted successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Supplier deletion failed", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
