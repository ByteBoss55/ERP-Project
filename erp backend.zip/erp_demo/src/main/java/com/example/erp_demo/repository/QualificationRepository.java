package com.example.erp_demo.repository;

import com.example.erp_demo.entity.QualificationMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QualificationRepository extends JpaRepository<QualificationMaster, Integer> {
}
