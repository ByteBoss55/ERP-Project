package com.example.erp_demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.erp_demo.entity.Machine;
import com.example.erp_demo.repository.MachineRepo;

@Service
public class MachineService {

	@Autowired
    private MachineRepo repo;
    
    public Machine create(Machine machine) {
        Long id = repo.create(machine);
        machine.setSrNo(id.intValue());
        return machine;
    }

    public List<Machine> getAllMachines() {
        return repo.getAllMachines();
    }

    public Machine getMachineById(Integer id) {
        return repo.getMachineById(id);
    }

    public boolean updateMachine(Machine machine) {
        return repo.updateMachine(machine);
    }

    public boolean deleteMachine(Integer id) {
        return repo.deleteMachine(id);
    }
}
