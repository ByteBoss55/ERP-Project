package com.example.erp_demo.repository;

import com.example.erp_demo.entity.CheckPointMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CheckPointRepository extends JpaRepository<CheckPointMaster, String> {
}
