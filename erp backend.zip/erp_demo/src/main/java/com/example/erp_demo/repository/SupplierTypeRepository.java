package com.example.erp_demo.repository;

import com.example.erp_demo.entity.SupplierTypeMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupplierTypeRepository extends JpaRepository<SupplierTypeMaster, Integer> {
}
