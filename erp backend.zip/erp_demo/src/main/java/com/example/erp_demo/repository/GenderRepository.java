package com.example.erp_demo.repository;

import com.example.erp_demo.entity.GenderMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GenderRepository extends JpaRepository<GenderMaster, Integer> {
}
