package com.example.erp_demo.repository;

import com.example.erp_demo.entity.AdminLoginUserMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminLoginUserRepository extends JpaRepository<AdminLoginUserMaster, Integer> {
}
