package com.example.erp_demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;

import com.example.erp_demo.entity.Employee;

public interface EmployeeRepoJPA extends JpaRepository<Employee, Long> {

	 @Procedure(procedureName = "master_customer_master_generateNextEmpCode")
	    String generateNextEmployeeCode();
	
	
	 Optional<Employee> findByEmpCode(String empCode);

    List<Employee> findByFirstNameContainingIgnoreCase(String name);


	Optional<Employee> findById(Long eSrNo);
}
