package com.example.erp_demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.example.erp_demo.entity.Employee;
import com.example.erp_demo.repository.EmployeeRepoJPA;
 

@Service 
public class EmployeeServiceJPAImpl implements EmployeeServiceJPA {

	
	@Autowired
	private EmployeeRepoJPA employeeRepo;
	
	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepo.findAll();
	}
	
	@Override
	public Employee saveEmployee(Employee employee) {

	    if (employee.getEmpCode() == null || employee.getEmpCode().isEmpty()) {
	        String nextCode = generateNextEmpCode();
	        employee.setEmpCode(nextCode);
	    }

	    return employeeRepo.save(employee);
	}

	private String generateNextEmpCode() {
	    Long count = employeeRepo.count() + 1; // get total count
	    return String.format("EMP%03d", count); // EMP001, EMP002, ...
	}

//	public Employee updateEmployeeWithCode(Integer eSrNo, Employee employee) {
//
//        Employee existing = employeeRepo.findById(eSrNo).orElse(null);
//        if (existing == null) {
//            return null;
//        }
//
//        // ❗ Keep old empCode — do not regenerate
//        employee.setEmpCode(existing.getEmpCode());
//        employee.setESrNo(eSrNo);
//
//        return employeeRepo.save(employee);
//    }
	
	@Override
	public Optional<Employee> getEmployeeById(Long eSrNo) {
		
		return  employeeRepo.findById(eSrNo);
	}

	@Override
	public Optional<Employee> getEmployeeByCode(String employeeCode) {
		 
		return employeeRepo.findByEmpCode(employeeCode);
	}

	@Override
	public Employee updateEmployee(Long eSrNo, Employee updatedEmployee) {
		return employeeRepo.findById(eSrNo)
	            .map(existing -> {
	                existing.setEmpCode(updatedEmployee.getEmpCode());
	                existing.setTitle(updatedEmployee.getTitle());
	                existing.setFirstName(updatedEmployee.getFirstName());
	                existing.setMiddleName(updatedEmployee.getMiddleName());
	                existing.setLastName(updatedEmployee.getLastName());
	                existing.setContactNo(updatedEmployee.getContactNo());
	                existing.setMobileNo(updatedEmployee.getMobileNo());
	                existing.setEmailId(updatedEmployee.getEmailId());
	                existing.setDate_of_join(updatedEmployee.getDateOfBirth());
	                existing.setgId(updatedEmployee.getgId());
	                existing.setBloodGroupId(updatedEmployee.getBloodGroupId());
	                existing.setMsId(updatedEmployee.getMsId());
	                existing.setCtc(updatedEmployee.getCtc());
	                existing.setGrossAmount(updatedEmployee.getGrossAmount());
	                existing.setTempAddress(updatedEmployee.getTempAddress());
	                existing.setDocument_name(updatedEmployee.getDocument_name());
	                existing.setTraining_details(updatedEmployee.getTraining_details());
	                existing.setPanNo(updatedEmployee.getPanNo());
	                existing.setEsicAccNo(updatedEmployee.getEsicAccNo());
	                existing.setAuto_mail(updatedEmployee.getAuto_mail());
	                existing.setLeave_id(updatedEmployee.getLeave_id());
	                existing.setAttendance_id(updatedEmployee.getAttendance_id());
	                existing.setEmp_photo(updatedEmployee.getEmp_photo());
	                existing.setDate_of_join(updatedEmployee.getDate_of_join());
	                existing.setQualificationId(updatedEmployee.getQualificationId());
	                existing.setDesignationId(updatedEmployee.getDesignationId());
	                existing.setDid(updatedEmployee.getDid());
	                existing.setCategory_id(updatedEmployee.getCategory_id());
	                existing.setWid(updatedEmployee.getWid());
	                existing.setContractorId(updatedEmployee.getContractorId());
	                existing.setStaff_id(updatedEmployee.getStaff_id());
	                existing.setPayTypeId(updatedEmployee.getPayTypeId());
	                existing.setUnitId(updatedEmployee.getUnitId());
	                existing.setAadharNo(updatedEmployee.getAadharNo());
	                existing.setBalance(updatedEmployee.getBalance());
	                existing.setPermanentAddress(updatedEmployee.getPermanentAddress());
	                existing.setAsset(updatedEmployee.getAsset());
	                existing.setApprasal_history(updatedEmployee.getApprasal_history());
	                existing.setPfacc_no(updatedEmployee.getPfacc_no());
	                existing.setIsLeft(updatedEmployee.getIsLeft());
	                existing.setLeftDate(updatedEmployee.getLeftDate());
	                existing.setCityId(updatedEmployee.getCityId());
	                existing.setStateId(updatedEmployee.getStateId());
	                existing.setCountryId(updatedEmployee.getCountryId());
	                existing.setCid(updatedEmployee.getCid());
	                return employeeRepo.save(existing);
	            })
	            .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + eSrNo));
	}

	@Override
	public void deleteEmployee(Long eSrNo) {
		if (!employeeRepo.existsById(eSrNo)) {
            throw new RuntimeException("Employee not found with ID: " + eSrNo);
        }
		employeeRepo.deleteById(eSrNo);
		
	}
}
