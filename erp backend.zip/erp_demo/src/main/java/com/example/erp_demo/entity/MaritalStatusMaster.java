package com.example.erp_demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "marital_status_master")
public class MaritalStatusMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "msid")
    private Integer msid;

    @Column(name = "marital_status", length = 50)
    private String maritalStatus;

    public Integer getMsid() {
        return msid;
    }

    public void setMsid(Integer msid) {
        this.msid = msid;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }
}

