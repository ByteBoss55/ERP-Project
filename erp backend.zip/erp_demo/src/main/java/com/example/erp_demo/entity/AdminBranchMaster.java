package com.example.erp_demo.entity;

 

import jakarta.persistence.*;

@Entity
@Table(name = "admin_branch_masteris_active")
public class AdminBranchMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "branch_id")
    private Integer branchId;

    @Column(name = "branch_name", length = 100)
    private String branchName;

    @Column(name = "is_active")
    private Boolean isActive;

    public Integer getBranchId() { return branchId; }
    public void setBranchId(Integer branchId) { this.branchId = branchId; }

    public String getBranchName() { return branchName; }
    public void setBranchName(String branchName) { this.branchName = branchName; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
}

