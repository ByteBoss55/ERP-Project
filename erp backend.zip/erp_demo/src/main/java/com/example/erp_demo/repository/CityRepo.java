package com.example.erp_demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.erp_demo.entity.City;

@Repository
public interface CityRepo extends JpaRepository<City, Integer> {

	List<City> findByState_StateId(Integer stateId);

     
     

}
