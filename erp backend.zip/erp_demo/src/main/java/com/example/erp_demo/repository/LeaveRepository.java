package com.example.erp_demo.repository;

import com.example.erp_demo.entity.LeaveMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeaveRepository extends JpaRepository<LeaveMaster, Integer> {
}
