package com.example.erp_demo.repository;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.erp_demo.entity.Item;
import com.example.erp_demo.entity.Supplier;

@Repository
public class SupplierRepo {

	@Autowired
    private JdbcTemplate jdbcTemplate;

	
	public String generateNextSuppCode() {
		return jdbcTemplate.execute((CallableStatementCreator) connection -> {
			CallableStatement cs = connection.prepareCall("{CALL master_supplier_master_generateNextSuppCode(?)}");
			cs. registerOutParameter(1,Types.VARCHAR);
			return cs;
		}, (CallableStatementCallback<String>) cs -> {
			cs.execute();
			return cs.getString(1);
		});
	}
     
	public Integer create(Supplier supplier) {
	    return jdbcTemplate.execute(
	        (CallableStatementCreator) connection -> {	            
	            CallableStatement cs = connection.prepareCall(
	                "{CALL master_supplier_master_save(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}"
	            );

	            cs.setString(1, supplier.getSuppCode());
	            cs.setString(2, supplier.getSuppName());
	            cs.setString(3, supplier.getContactPerson());
	            cs.setString(4, supplier.getBranch());
	            cs.setString(5, supplier.getAddress1());
	            cs.setString(6, supplier.getAddress2());
	            cs.setString(7, supplier.getPinCode());
	            cs.setString(8, supplier.getEmailId());
	            cs.setLong(9, supplier.getTelephone());
	            cs.setLong(10, supplier.getMobile());
	            cs.setString(11, supplier.getFax());
	            cs.setString(12, supplier.getWebsite());
	            cs.setString(13, supplier.getGstIn());
	            cs.setString(14, supplier.getRemarks());
	            cs.setString(15, supplier.getUsername());
	            cs.setString(16, supplier.getLoginBranch());
	            cs.setString(17, supplier.getSystemEntryDate());
	            cs.setInt(18, supplier.getSuppTypeId() == null ? 0 : supplier.getSuppTypeId());
	            cs.setInt(19, supplier.getCountryId() == null ? 0 : supplier.getCountryId());
	            cs.setInt(20, supplier.getStateId() == null ? 0 : supplier.getStateId());
	            cs.setInt(21, supplier.getCityId() == null ? 0 : supplier.getCityId());
	            cs.setInt(22, 1);
	            cs.setInt(23, 1);  
	            return cs;
	            
			}, (CallableStatementCallback<Integer>) cs -> {
				cs.execute();
				return 1;
			});
		}

     
    public List<Supplier> getAllSuppliers() {
        return jdbcTemplate.execute((ConnectionCallback<List<Supplier>>) con -> {
            try (var cs = con.prepareCall("{CALL master_supplier_master_getAll()}")) {
                List<Supplier> list = new ArrayList<>();
                try (ResultSet rs = cs.executeQuery()) {
                    while (rs.next()) {
                        Supplier s = new Supplier();
                        s.setId(rs.getInt("id"));
                        s.setSuppCode(rs.getString("supp_code"));
                        s.setSuppName(rs.getString("supp_name"));
                        s.setContactPerson(rs.getString("contact_person"));
                        s.setBranch(rs.getString("branch"));
                        s.setAddress1(rs.getString("address1"));
                        s.setAddress2(rs.getString("address2"));
                        s.setPinCode(rs.getString("pin_code"));
                        s.setEmailId(rs.getString("email_id"));
                        s.setTelephone(rs.getLong("telephone"));
                        s.setMobile(rs.getLong("mobile"));
                        s.setFax(rs.getString("fax"));
                        s.setWebsite(rs.getString("website"));
                        s.setGstIn(rs.getString("gst_in"));
                        s.setRemarks(rs.getString("remarks"));
                        s.setLoginBranch(rs.getString("login_branch"));
                        s.setSystemEntryDate(rs.getString("system_entry_date"));
                        s.setSuppTypeId(rs.getInt("supp_type_id"));
                        s.setCountryId(rs.getInt("country_id"));
                        s.setStateId(rs.getInt("state_id"));
                        s.setCityId(rs.getInt("city_id"));
                        s.setBranchId(rs.getInt("branch_id"));
                        s.setLoginUserId(rs.getInt("login_user_id"));
                        s.setcountryName(rs.getString("country_name"));
                        s.setstateName(rs.getString("state_name"));
                        s.setcityName(rs.getString("city_name"));
                        s.setbranchName(rs.getString("branch_name"));
                        s.setsuppType(rs.getString("supp_type"));
                        s.setuserName(rs.getString("user_name"));
                        list.add(s);
                    }
                }
                return list;
            }
        });
    }

     
    public Supplier getSupplierById(Integer id) {
        return jdbcTemplate.execute((ConnectionCallback<Supplier>) con -> {
            try (var cs = con.prepareCall("{CALL master_supplier_master_getById(?)}")) {
                cs.setInt(1, id);
                try (ResultSet rs = cs.executeQuery()) {
                    if (rs.next()) {
                        Supplier s = new Supplier();
                        s.setId(rs.getInt("id"));
                        s.setSuppCode(rs.getString("supp_code"));
                        s.setSuppName(rs.getString("supp_name"));
                        s.setContactPerson(rs.getString("contact_person"));
                        s.setBranch(rs.getString("branch"));
                        s.setAddress1(rs.getString("address1"));
                        s.setAddress2(rs.getString("address2"));
                        s.setPinCode(rs.getString("pin_code"));
                        s.setEmailId(rs.getString("email_id"));
                        s.setTelephone(rs.getLong("telephone"));
                        s.setMobile(rs.getLong("mobile"));
                        s.setFax(rs.getString("fax"));
                        s.setWebsite(rs.getString("website"));
                        s.setGstIn(rs.getString("gst_in"));
                        s.setRemarks(rs.getString("remarks"));
                        s.setUsername(rs.getString("username"));
                        s.setLoginBranch(rs.getString("login_branch"));
                        s.setSystemEntryDate(rs.getString("system_entry_date"));
                        s.setSuppTypeId(rs.getInt("supp_type_id"));
                        s.setCountryId(rs.getInt("country_id"));
                        s.setStateId(rs.getInt("state_id"));
                        s.setCityId(rs.getInt("city_id"));
                        s.setBranchId(rs.getInt("branch_id"));
                        s.setLoginUserId(rs.getInt("login_user_id"));
                        return s;
                    }
                }
            }
            return null;
        });
    }

     
    public boolean updateSupplier(Supplier supplier) {
        String sql = "{CALL master_supplier_master_update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        int rowsAffected = jdbcTemplate.update(connection -> {
            var cs = connection.prepareCall(sql);
            cs.setInt(1, supplier.getId());
            cs.setString(2, supplier.getSuppCode());
            cs.setString(3, supplier.getSuppName());
            cs.setString(4, supplier.getContactPerson());
            cs.setString(5, supplier.getBranch());
            cs.setString(6, supplier.getAddress1());
            cs.setString(7, supplier.getAddress2());
            cs.setString(8, supplier.getPinCode());
            cs.setString(9, supplier.getEmailId());
            cs.setLong(10, supplier.getTelephone());
            cs.setLong(11, supplier.getMobile());
            cs.setString(12, supplier.getFax());
            cs.setString(13, supplier.getWebsite());
            cs.setString(14, supplier.getGstIn());
            cs.setString(15, supplier.getRemarks());
            cs.setString(16, supplier.getUsername());
            cs.setString(17, supplier.getLoginBranch());
            cs.setString(18, supplier.getSystemEntryDate());
            cs.setInt(19, supplier.getSuppTypeId());
            cs.setInt(20, supplier.getCountryId());
            cs.setInt(21, supplier.getStateId());
            cs.setInt(22, supplier.getCityId());
            cs.setInt(23, supplier.getBranchId());
            return cs;
        });

        return rowsAffected > 0;
    }

    
    public boolean deleteSupplier(Integer id) {
        String sql = "{CALL master_supplier_master_deleteById(?)}";

        int rowsAffected = jdbcTemplate.update(connection -> {
            var cs = connection.prepareCall(sql);
            cs.setInt(1, id);
            return cs;
        });

        return rowsAffected > 0;
    }
    
     
}
