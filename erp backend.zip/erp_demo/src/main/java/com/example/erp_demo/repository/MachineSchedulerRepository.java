package com.example.erp_demo.repository;

import com.example.erp_demo.entity.MachineScheduler;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MachineSchedulerRepository extends JpaRepository<MachineScheduler, Integer> {
}

